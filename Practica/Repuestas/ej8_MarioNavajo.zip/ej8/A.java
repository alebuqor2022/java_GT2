package ej8;

public class A {

	public A() {
		// TODO Auto-generated constructor stub
	}
	public void a() throws Exception{
		 throw new Exception("ExcepcionA");
	}
	public void b() {
		 throw new RuntimeException("ExcepcionB");
	}
}
