package ej8;

public class C {

	public static void main(String[] args) {
		A objetoa= new A();
		try {
			objetoa.a();
		} catch (Exception e) {
			
			e.printStackTrace();
			System.out.println("Genere un error en la clase C");
		}
		objetoa.b();
		
	}
	//Segunda forma de solucion
	public static void main1(String[] args) throws Exception{
		A objetoa= new A();
		objetoa.a();
	}
}
