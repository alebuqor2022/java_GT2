/**
 * 
 */
/**
 * @author iespigares
 *
 */
module BinaryNodes {
}