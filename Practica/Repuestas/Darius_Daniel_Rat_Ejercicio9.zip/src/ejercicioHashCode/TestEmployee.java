package ejercicioHashCode;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

public class TestEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		SimpleDateFormat date=new SimpleDateFormat("yyyy-MM-dd");
		
		
		try {
			Employee e=new Employee(date.parse("2022-10-12"),1207,"Ramirez",date.parse("2000-01-30"));
			Employee e2=new Employee(date.parse("2022-10-12"),1200,"Ramirez",date.parse("2001-11-23"));
			
			Employee e3=e;
			
			System.out.println(e.toString());
			System.out.println(e2.toString());
			
			//equals
			System.out.println("Equals: " + e.equals(e2));
			
			//hashcode
			System.out.println("Hashcode: " + e.hashCode());
			System.out.println("Hashcode: " + e2.hashCode());
			
			System.out.println("Hashcode: " + e3.hashCode());
			
			//Me saca el hash de la variable nombre
		//	System.out.println(Objects.hashCode(e.getNombre()));
			
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		

	}

}
