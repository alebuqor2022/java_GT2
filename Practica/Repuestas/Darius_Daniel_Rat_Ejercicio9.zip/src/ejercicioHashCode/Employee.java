package ejercicioHashCode;

import java.util.Date;

public class Employee {

	private Date fechaIngreso;
	private double salario;
	private String nombre;
	private Date fechaNacimiento;
	
	
	public Employee(Date fechaIngreso, double salario,String nombre,Date fechaNacimiento) {
		
		this.fechaIngreso=fechaIngreso;
		this.salario=salario;
		this.nombre=nombre;
		this.fechaNacimiento=fechaNacimiento;
		
	}


	public Date getFechaIngreso() {
		return fechaIngreso;
	}


	public void setFechaIngreso(Date fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}


	public double getSalario() {
		return salario;
	}


	public void setSalario(double salario) {
		this.salario = salario;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}


	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	@Override
	public int hashCode() {
		
		int hash=5;
		
		hash = 23 * hash + this.nombre.hashCode();
		hash = 23 * hash + this.fechaNacimiento.hashCode();
		hash = 23 * hash + Double.valueOf(this.salario).hashCode();
		hash = 23 * hash + this.fechaIngreso.hashCode();
		
		return hash; //return Objects.hash(fechaIngreso,nombre,salario);
	}
	
	
	//Con el getTime() comparo las fechas en milisegundos desde el 1 de enero de 1970
	@Override
	public boolean equals(Object o) {
		
		if(this==o)
			return true;
		Employee e=(Employee)o;
		
		if(this.getNombre().equalsIgnoreCase(e.getNombre()) && 
				this.getFechaNacimiento().getTime()==e.getFechaNacimiento().getTime() &&
				this.getSalario()==e.getSalario() && this.getFechaIngreso().getTime()== e.getFechaIngreso().getTime()){
			return true;
		}
		
		return false;
	}

	@Override
	public String toString() {
		return "Employee [fechaIngreso=" + fechaIngreso + ", salario=" + salario + ", nombre=" + nombre + ", Fecha Nacimiento=" 
	+ fechaNacimiento + "]";
	}
	
	
	
	
}
