package ej13;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class PersonasUtil {

	public static void getPersonas(ArrayList <Persona> listaPersonas) {
		HashMap <Integer, Persona> resultado = new HashMap <Integer, Persona>();
		
		//recibe una lista y la almacena en un Map
		for (Persona p: listaPersonas) {
			resultado.put(p.getLegajo(), new Persona(p.getLegajo(), p.getEdad(), p.getNombre()));
			//resultado.put(p.getLegajo(), new Persona(p.getEdad(), p.getNombre())); //Por si no fuera necesario repetir el legajo
		}
	
		//Para recorrer el map. Se sacan las claves, se itera sobre ellas y se van mostrando los datos.
		Set <Integer> claves = resultado.keySet();
		Iterator <Integer> it = claves.iterator();
		while (it.hasNext()) {
			int clave = it.next();
			Persona tmp = resultado.get(clave);
			System.out.println("Legajo: "+clave/*tmp.getLegajo()*/+". Nombre: " + tmp.getNombre() + ", Edad: " + tmp.getEdad());
		}
	}	
}