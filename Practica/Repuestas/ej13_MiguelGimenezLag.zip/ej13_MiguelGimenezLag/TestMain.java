package ej13;

import java.util.ArrayList;

public class TestMain {

	public static void main(String[] args) {
		Persona p1 = new Persona(123,22,"Manolo");
		Persona p2 = new Persona(456, 40, "Ana");
		
		ArrayList <Persona> listaPersonas = new ArrayList <Persona>();
		listaPersonas.add(p1);
		listaPersonas.add(p2);
		listaPersonas.add(new Persona(789, 30, "Pepe"));
		
		PersonasUtil.getPersonas(listaPersonas);
		
		
	}

}
