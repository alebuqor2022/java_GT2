package ej13;

public class Persona {
	private int legajo;
	private int edad;
	private String nombre;
	
	public Persona() {}
	/*
	public Persona(int edad, String n) {  //para poder construir Personas sin legajo si consideramos que con guardarlo en la clave es suficiente.
		this.edad = edad;
		this.nombre = n;
	}*/
	
	public Persona(int lega, int edad, String n) {
		this.legajo = lega;
		this.edad = edad;
		this.nombre = n;
	}
	
	public int getLegajo() {
		return legajo;
	}
	public void setLegajo(int legajo) {
		this.legajo = legajo;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
}
