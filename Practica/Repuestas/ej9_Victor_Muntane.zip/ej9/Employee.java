package ej9;

import java.util.Date;
import java.util.Objects;

public class Employee {
	private Date fechaIngreso;
	private double salario;
	private String nombre;
	
	public Employee(Date fechaIngreso, double salario, String nombre) {
		this.fechaIngreso = fechaIngreso;
		this.salario = salario;
		this.nombre = nombre;
	}

	@Override
	public int hashCode() {
		return Objects.hash(fechaIngreso, nombre, salario);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return Objects.equals(fechaIngreso, other.fechaIngreso) && Objects.equals(nombre, other.nombre)
				&& Double.doubleToLongBits(salario) == Double.doubleToLongBits(other.salario);
	}
	
}