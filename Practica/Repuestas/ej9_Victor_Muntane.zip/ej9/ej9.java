package ej9;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class ej9 {

	public static void main(String[] args) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		Date date = formatter.parse("03-10-2022");
		Employee Empleado = new Employee(date, 45000, "Víctor Muntané fuentes");
		Employee Empleado1 = Empleado;
		Employee Empleado2 = new Employee(date, 5000, "Enrique Lopez");
		Employee Empleado3 = new Employee(date, 5000, "Enrique Lopez");
		System.out.println(Empleado.equals(Empleado1));
		System.out.println(Empleado.hashCode());
		System.out.println(Empleado2.hashCode());
		System.out.println(Empleado2.equals(Empleado3));
	}

}
