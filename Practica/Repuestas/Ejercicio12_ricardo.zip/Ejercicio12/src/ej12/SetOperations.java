package ej12;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetOperations {
	
	public static <T> Set<T> union(Set<T> setA, Set<T> setB){
		TreeSet union = new TreeSet();
		union.addAll(setA);
		union.addAll(setB);
		return union;
		
	}
	
	public static <T> Set<T> interseccion(Set<T> setA, Set<T> setB){
		TreeSet interseccion = new TreeSet();
		for(T s: setA) {
			if(setB.contains(s)) {
				interseccion.add(s);
			}
		}
		
		return interseccion;
	}
	public static <T> Set<T> diferencia(Set<T> setA, Set<T> setB){
		TreeSet diferencia = new TreeSet();
		for(T s: setA) {
			if(!setB.contains(s)) {
				diferencia.add(s);
			}
		}
		
		for(T s: setB) {
			if(!setA.contains(s)) {
				diferencia.add(s);
			}
		}
		
		return diferencia;
	}

	public static void main(String[] args) {
		TreeSet setA = new TreeSet();
		TreeSet setB = new TreeSet();
		setA.add(1);
		setA.add(2);
		setA.add(3);
		setA.add(89);
		
		setB.add(3);
		setB.add(4);
		setB.add(5);
		setB.add(61);
		setB.add(89);
		
		TreeSet union = (TreeSet) SetOperations.union(setA, setB);
		System.out.println(union);
		
		TreeSet interseccion = (TreeSet) SetOperations.interseccion(setA, setB);
		System.out.println(interseccion);
		
		TreeSet diferencia = (TreeSet) SetOperations.diferencia(setA, setB);
		System.out.println(diferencia);
	}

}
