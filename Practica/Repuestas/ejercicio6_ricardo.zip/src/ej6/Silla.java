package ej6;

public class Silla {

}
