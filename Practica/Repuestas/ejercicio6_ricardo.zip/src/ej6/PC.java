package ej6;

public class PC {

}
