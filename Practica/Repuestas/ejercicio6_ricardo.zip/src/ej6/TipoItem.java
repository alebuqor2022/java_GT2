package ej6;

public enum TipoItem {

}
