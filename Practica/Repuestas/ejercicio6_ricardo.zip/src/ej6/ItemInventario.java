package ej6;

public abstract class ItemInventario {

}
