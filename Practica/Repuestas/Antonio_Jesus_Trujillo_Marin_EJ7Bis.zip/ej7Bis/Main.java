package ej7Bis;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;

public class Main {

	public static void main(String[] args) {
		// Ordenar array de enteros
		
		int[] array= {
				1,5,3,7,8,9,2,4,6
		};
		
		//Antes de ser ordenado.
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
		System.out.println();
		//Llamada a metodo sort.
		Arrays.sort(array);
		System.out.println("Ordenado:");
		
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i]+ " ");
		}
	}

}
