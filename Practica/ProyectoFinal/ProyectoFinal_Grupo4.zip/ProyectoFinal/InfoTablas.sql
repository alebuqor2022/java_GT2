INSERT INTO `indragt2f`.`libros` (`id_libro`, `anyo`, `editorial`, `fecha_nacimiento`, `nacionalidad_autor`, `nombre_autor`, `tipo`, `titulo`) VALUES ('1222', '1950', 'Ed1', '1901-01-15', 'Británica', 'J.R.R Tolkien', 'novela', 'El Señor de los Anillos');
INSERT INTO `indragt2f`.`libros` (`id_libro`, `anyo`, `editorial`, `fecha_nacimiento`, `nacionalidad_autor`, `nombre_autor`, `tipo`, `titulo`) VALUES ('1233', '1941', 'Ed USA', '1899-05-19', 'Estadounidense', 'E. Hemingway', 'novela', '¿Por quién doblan las campanas?');
INSERT INTO `indragt2f`.`libros` (`id_libro`, `anyo`, `editorial`, `fecha_nacimiento`, `nacionalidad_autor`, `nombre_autor`, `tipo`, `titulo`) VALUES ('2121', '1960', 'Ed Ensayos', '1910-12-20', 'Húngara', 'K. Polanyi', 'ensayo', 'La Gran Transformación');
INSERT INTO `indragt2f`.`libros` (`id_libro`, `anyo`, `editorial`, `fecha_nacimiento`, `nacionalidad_autor`, `nombre_autor`, `tipo`, `titulo`) VALUES ('3001', '1959', 'Ed Poetas', '1912-1-06', 'Chilena', 'P. Neruda', 'poesia', 'Veinte poemas de amor y una canción desesperada');
INSERT INTO `indragt2f`.`libros` (`id_libro`, `anyo`, `editorial`, `fecha_nacimiento`, `nacionalidad_autor`, `nombre_autor`, `tipo`, `titulo`) VALUES ('4010', '1610', 'Ed Viejuno', '1590-04-12', 'Española', 'L. de Vega', 'teatro', 'Fuenteovejuna');
INSERT INTO `indragt2f`.`libros` (`id_libro`, `anyo`, `editorial`, `fecha_nacimiento`, `nacionalidad_autor`, `nombre_autor`, `tipo`, `titulo`) VALUES ('1321', '1990', 'Ed1', '1960-02-01', 'Estadounidense', 'R. Jordan', 'novela', 'El ojo del mundo');
INSERT INTO `indragt2f`.`libros` (`id_libro`, `anyo`, `editorial`, `fecha_nacimiento`, `nacionalidad_autor`, `nombre_autor`, `tipo`, `titulo`) VALUES ('1400', '2012', 'Ed USA', '1980-07-29', 'Estadounidense', 'P. Rothfuss', 'novela', 'El Nombre del Viento');
INSERT INTO `indragt2f`.`libros` (`id_libro`, `anyo`, `editorial`, `fecha_nacimiento`, `nacionalidad_autor`, `nombre_autor`, `tipo`, `titulo`) VALUES ('2020', '1850', 'Ed Ensayo', '1812-10-10', 'Estadounidense', 'H. D. Thoreau', 'ensayo', 'Desobediencia Civil');
INSERT INTO `indragt2f`.`libros` (`id_libro`, `anyo`, `editorial`, `fecha_nacimiento`, `nacionalidad_autor`, `nombre_autor`, `tipo`, `titulo`) VALUES ('3050', '1937', 'Ed Poetas', '1910-10-30', 'Española', 'M. Hernández', 'poesia', 'Viento del pueblo');
INSERT INTO `indragt2f`.`libros` (`id_libro`, `anyo`, `editorial`, `fecha_nacimiento`, `nacionalidad_autor`, `nombre_autor`, `tipo`, `titulo`) VALUES ('4444', '1636', 'Ed Viejuno', '1600-01-01', 'Española', 'T. de Molina', 'teatro', 'El Burlador de Sevilla');


INSERT INTO `indragt2f`.`lectores` (`n_socio`, `direccion`, `nombre`, `telefono`) VALUES ('1', 'Calle Aceituna', 'Lector 1', '666-66-66-66');
INSERT INTO `indragt2f`.`lectores` (`n_socio`, `direccion`, `nombre`, `telefono`) VALUES ('2', 'Calle Puchero', 'Lector 2', '655-55-66-55');


INSERT INTO `indragt2f`.`copia_libro` (`id_copia`, `estado_copia`, `fk_id_libro`) VALUES ('1', 'biblioteca', '1222');
INSERT INTO `indragt2f`.`copia_libro` (`id_copia`, `estado_copia`, `fk_id_libro`) VALUES ('2', 'biblioteca', '1222');
INSERT INTO `indragt2f`.`copia_libro` (`id_copia`, `estado_copia`, `fk_id_libro`) VALUES ('3', 'prestado', '1222');
INSERT INTO `indragt2f`.`copia_libro` (`id_copia`, `estado_copia`, `fk_id_libro`) VALUES ('4', 'reparacion', '1233');
INSERT INTO `indragt2f`.`copia_libro` (`id_copia`, `estado_copia`, `fk_id_libro`) VALUES ('5', 'biblioteca', '1321');
INSERT INTO `indragt2f`.`copia_libro` (`id_copia`, `estado_copia`, `fk_id_libro`) VALUES ('6', 'prestado', '1321');
INSERT INTO `indragt2f`.`copia_libro` (`id_copia`, `estado_copia`, `fk_id_libro`) VALUES ('7', 'prestado', '1400');
INSERT INTO `indragt2f`.`copia_libro` (`id_copia`, `estado_copia`, `fk_id_libro`) VALUES ('8', 'prestado', '2020');
INSERT INTO `indragt2f`.`copia_libro` (`id_copia`, `estado_copia`, `fk_id_libro`) VALUES ('9', 'biblioteca', '2020');
INSERT INTO `indragt2f`.`copia_libro` (`id_copia`, `estado_copia`, `fk_id_libro`) VALUES ('10', 'prestado', '2121');
INSERT INTO `indragt2f`.`copia_libro` (`id_copia`, `estado_copia`, `fk_id_libro`) VALUES ('11', 'reparacion', '2121');
INSERT INTO `indragt2f`.`copia_libro` (`id_copia`, `estado_copia`, `fk_id_libro`) VALUES ('12', 'biblioteca', '3001');
INSERT INTO `indragt2f`.`copia_libro` (`id_copia`, `estado_copia`, `fk_id_libro`) VALUES ('13', 'biblioteca', '3001');
INSERT INTO `indragt2f`.`copia_libro` (`id_copia`, `estado_copia`, `fk_id_libro`) VALUES ('14', 'biblioteca', '3050');
INSERT INTO `indragt2f`.`copia_libro` (`id_copia`, `estado_copia`, `fk_id_libro`) VALUES ('15', 'biblioteca', '4010');
INSERT INTO `indragt2f`.`copia_libro` (`id_copia`, `estado_copia`, `fk_id_libro`) VALUES ('16', 'biblioteca', '4444');

INSERT INTO `indragt2f`.`prestamos` (`id_prestamo`,`fecha_fin`, `fecha_inicio`, `pk_fk_copia`, `fk_socio`) VALUES (1, '2022-12-06', '2022-11-06', '3', '1');
INSERT INTO `indragt2f`.`prestamos` (`id_prestamo`,`fecha_fin`, `fecha_inicio`, `pk_fk_copia`, `fk_socio`) VALUES (2, '2022-12-06', '2022-11-06', '6', '1');
INSERT INTO `indragt2f`.`prestamos` (`id_prestamo`,`fecha_fin`, `fecha_inicio`, `pk_fk_copia`, `fk_socio`) VALUES (3, '2022-12-06', '2022-11-06', '7', '1');
INSERT INTO `indragt2f`.`prestamos` (`id_prestamo`,`fecha_fin`, `fecha_inicio`, `pk_fk_copia`, `fk_socio`) VALUES (4, '2022-12-01', '2022-11-01', '8', '2');
INSERT INTO `indragt2f`.`prestamos` (`id_prestamo`,`fecha_fin`, `fecha_inicio`, `pk_fk_copia`, `fk_socio`) VALUES (5, '2022-10-31', '2022-10-01', '10', '2');