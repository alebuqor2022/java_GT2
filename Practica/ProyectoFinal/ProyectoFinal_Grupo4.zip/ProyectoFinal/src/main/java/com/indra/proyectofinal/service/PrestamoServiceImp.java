package com.indra.proyectofinal.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.proyectofinal.model.Prestamo;
import com.indra.proyectofinal.repository.PrestamoRepository;

@Service
public class PrestamoServiceImp implements PrestamoService{
	
	@Autowired 
	private PrestamoRepository prestamoRepository;
	
	@Override
	public List<Prestamo> getAllPrestamos() {
		return this.prestamoRepository.findAll();
	}
	
	@Override
	public List<Prestamo> getAllPrestamosByLector(long id) {
		List<Prestamo> listaTotal = this.prestamoRepository.findAll();
		List<Prestamo> resultado = new ArrayList<Prestamo>();
		for (Prestamo p: listaTotal) {
			if(p.getLector().getnSocio() == id) {
				resultado.add(p);
			}
		}
		return resultado;
	}

	@Override
	public void savePrestamo(Prestamo prestamo) {
		this.prestamoRepository.save(prestamo);
	}

	@Override
	public Prestamo getPrestamoById(long id) {
		Optional<Prestamo> optionalPrestamo=this.prestamoRepository.findById(id);
		Prestamo prestamo = null;
		if(optionalPrestamo.isPresent()) {
			prestamo = optionalPrestamo.get();
		}else {
			throw new RuntimeException("El pr�stamo con id "+ id +" no se encuentra");
		}
		return prestamo;
	}

	@Override
	public void deletePrestamoById(long id) {
		this.prestamoRepository.deleteById(id);
		
	}

}