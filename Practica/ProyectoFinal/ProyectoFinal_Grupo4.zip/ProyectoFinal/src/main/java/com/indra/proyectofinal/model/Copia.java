package com.indra.proyectofinal.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="copia_libro")
public class Copia {
	@SuppressWarnings("unused")
	private static final long serialVersionUID= -1L;
	
    @Id
    @Column
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	private long idCopia;
    
    @Column
    @Enumerated(value = EnumType.STRING)
    private estadoCopia estadoCopia;
    
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="fk_id_libro")
    private Libro libro;

    
    public Copia() {

	}
    
	public Copia(long idCopia, com.indra.proyectofinal.model.estadoCopia estadoCopia, Libro libro) {
		this.idCopia = idCopia;
		this.estadoCopia = estadoCopia;
		this.libro = libro;
	}

	public long getIdCopia() {
		return idCopia;
	}

	public void setIdCopia(long idCopia) {
		this.idCopia = idCopia;
	}

	public estadoCopia getEstadoCopia() {
		return estadoCopia;
	}

	public void setEstadoCopia(estadoCopia estadoCopia) {
		this.estadoCopia = estadoCopia;
	}

	public Libro getLibro() {
		return libro;
	}

	public void setLibro(Libro libro) {
		this.libro = libro;
	}
    
}