package com.indra.proyectofinal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;


import com.indra.proyectofinal.model.Copia;

import com.indra.proyectofinal.service.CopiaService;

@Controller
public class CopiaController {
	
	@Autowired
	private CopiaService copiaService;
	
	@GetMapping("/copia")
	public String viewHomePage(Model model) {
		List<Copia> listCopias = this.copiaService.getAllCopias();
		model.addAttribute("listCopias", listCopias);	
		return "copia";
	}
	
	@PostMapping("/copia/save")
	public String saveCopia(@ModelAttribute("copy") Copia copia) {
		this.copiaService.saveCopia(copia);
	return "redirect:/copia";
	}
	
	@GetMapping("/copia/delete/{id}")
	public String deleteCopia(@PathVariable(value="id") long id) {
		this.copiaService.deleteCopiaById(id);
		return "redirect:/copia";
	}
	
	@GetMapping("/copia/update/{id}")
	public String showFormForUpdate(@PathVariable(value="id") long id, Model model) {
		Copia copia=this.copiaService.getCopiaById(id);
		model.addAttribute("copy", copia);
		return "update_copy";
	}
	
	@GetMapping("/copia/add")
	public String showNewLibroForm(Model model) {
		Copia copia = new Copia();
		model.addAttribute("copy", copia);
		return "new_copy";
	}
}