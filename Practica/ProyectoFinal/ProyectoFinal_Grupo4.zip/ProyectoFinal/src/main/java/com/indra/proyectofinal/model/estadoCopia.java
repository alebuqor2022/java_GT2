package com.indra.proyectofinal.model;

public enum estadoCopia {
	//PRESTADO, RETRASO, BIBLIOTECA, REPARACION
	prestado, retraso, biblioteca, reparacion
}
