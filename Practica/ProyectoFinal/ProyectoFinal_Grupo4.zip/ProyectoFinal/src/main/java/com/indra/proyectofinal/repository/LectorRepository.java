package com.indra.proyectofinal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.indra.proyectofinal.model.Lector;

public interface LectorRepository extends JpaRepository<Lector, Long>{

}
