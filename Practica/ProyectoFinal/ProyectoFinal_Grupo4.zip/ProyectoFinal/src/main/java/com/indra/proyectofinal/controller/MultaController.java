package com.indra.proyectofinal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.indra.proyectofinal.model.Multa;
import com.indra.proyectofinal.service.MultaService;

@Controller
public class MultaController {
	
	@Autowired
	private MultaService multaService;
	
	@GetMapping("/multa")
	public String viewHomePage(Model model) {
		List<Multa> listMultas = this.multaService.getAllMultas();
		model.addAttribute("listMultas", listMultas);	
		return "multa";
	}

}
