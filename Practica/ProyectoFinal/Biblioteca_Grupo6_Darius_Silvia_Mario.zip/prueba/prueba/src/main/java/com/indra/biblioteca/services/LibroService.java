package com.indra.biblioteca.services;

import java.util.List;

import com.indra.biblioteca.model.Libro;


public interface LibroService {
    List<Libro> getAllLibros();
    void saveLibro(Libro libro);
    Libro getLibroById(int ISBN);
    void deleteLibroById(int ISBN);

    //Metodo para paginacion de los datos

    //Los parametros son:numero de pagina, tamaño de esa pagina,

    //porque campo lo ordeno y si es asc o desc

    //Page <Autor>findPaginated(int pageNum, int pageSize, String sortField,String sortDirection);

}
