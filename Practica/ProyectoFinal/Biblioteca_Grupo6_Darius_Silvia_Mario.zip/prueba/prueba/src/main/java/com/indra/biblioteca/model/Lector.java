package com.indra.biblioteca.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@Table(name="lector")
public class Lector implements Serializable{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int numeroSocio;
	@Column(name="nombre")
	private String nombre;
	@Column(name="telefono")
	private String telefono;
	@Column(name="direccion")
	private String direccion;
	
	@Transient
    @OneToMany(fetch=FetchType.LAZY,mappedBy="lector",targetEntity=Prestamo.class,cascade=CascadeType.ALL,orphanRemoval = true)
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    @JoinColumn(name="lector",referencedColumnName = "numeroSocio")
	private Set<Prestamo> prestamos;
	
	@Transient
    @OneToMany(fetch=FetchType.LAZY,mappedBy="lector",targetEntity=Multa.class,cascade=CascadeType.ALL)
	@JoinColumn(name="lector",referencedColumnName = "numeroSocio")
    private Set<Multa> multa;

	public Lector() {
		super();
	}

	public Lector(int numeroSocio, String nombre, String telefono, String direccion,Set<Multa> multa,Set<Prestamo> prestamos) {
		super();
		this.numeroSocio = numeroSocio;
		this.nombre = nombre;
		this.telefono = telefono;
		this.direccion = direccion;
		this.multa = multa;
		this.prestamos = prestamos;
	}


	public int getNumeroSocio() {
		return numeroSocio;
	}
	
	public void setNumeroSocio(int numeroSocio) {
		this.numeroSocio = numeroSocio;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getTelefono() {
		return telefono;
	}
	
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	
	public String getDireccion() {
		return direccion;
	}
	
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public Set<Multa> getMulta() {
		return multa;
	}

	public void setMulta(Set<Multa> multa) {
		this.multa = multa;
	}

	public Set<Prestamo> getPrestamos() {
		return prestamos;
	}

	public void setPrestamos(Set<Prestamo> prestamos) {
		this.prestamos = prestamos;
	}

	/*
	public void devolver(int idCopia,String FechaActual) {
		//prestamos no este vacio	
	}
	public void prestar(int idCopia,String FechaActual) {
		//multa==0
	}
	
	public void multar(int dias) {
		//se suma dos dias de multa por cada dia de retraso
	}*/
	
}
