package com.indra.biblioteca.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table (name="libro")
public class Libro implements Serializable{

	@Id
    @Column(name="ISBN")
    private int ISBN;
    @Column(name="titulo")
    private String titulo;
    @Column(name="tipo")
    @Enumerated(EnumType.STRING)
    private tipoLibro tipo;
    @Column(name="editorial")
    private String editorial;
    @Column(name="anno")
    @Temporal(TemporalType.DATE)
    private Date anno;

    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="autor")
    private Autor autor;
    
    @Transient
    @OneToMany(fetch=FetchType.LAZY,mappedBy="copias",targetEntity=Copia.class,cascade=CascadeType.ALL,orphanRemoval = true)
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    @JoinColumn(name="copias",referencedColumnName = "ISBN")
    private Set<Copia> copias;
    
    public Libro() {
       super();
    }

   public Libro(int iSBN, String titulo, tipoLibro tipoLibro, String editorial, Date anno,
            Autor autor,Set<Copia> copias){
        super();
        this.ISBN = iSBN;
        this.titulo = titulo;
        this.tipo = tipoLibro;
        this.editorial = editorial;
        this.anno = anno;
        this.autor = autor;
        this.copias=copias;
    }

   public int getISBN() {
        return ISBN;
    }

   public void setISBN(int iSBN) {
        ISBN = iSBN;
    }

   public String getTitulo() {
        return titulo;
    }

   public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

   public tipoLibro getTipoLibro() {
        return tipo;
    }

   public void setTipoLibro(tipoLibro tipoLibro) {
        this.tipo = tipoLibro;
    }

   public String getEditorial() {
        return editorial;
    }

   public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

   public Date getAnno() {
        return anno;
    }

   public void setAnno(Date anno) {
        this.anno = anno;
    }

   public Autor getAutor() {
        return autor;
    }

   public void setAutor(Autor autor) {
        this.autor = autor;
    }

   public Set<Copia> getCopias() {
        return copias;
    }

   public void setCopias(Set<Copia> copias) {
        this.copias = copias;
    }
}