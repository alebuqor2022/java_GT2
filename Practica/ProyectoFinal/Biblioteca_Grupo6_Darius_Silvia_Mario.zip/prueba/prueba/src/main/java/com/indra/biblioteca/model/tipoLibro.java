package com.indra.biblioteca.model;

public enum tipoLibro {
	NOVELA,TEATRO,POESIA,ENSAYO	
}
