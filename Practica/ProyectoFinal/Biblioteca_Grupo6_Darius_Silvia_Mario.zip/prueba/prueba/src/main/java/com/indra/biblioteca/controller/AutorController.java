package com.indra.biblioteca.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.indra.biblioteca.model.Autor;
import com.indra.biblioteca.services.AutorService;


@RestController
@RequestMapping(path="/autor")
public class AutorController {
	
	@Autowired
	private AutorService autorservicio;
	
	//Obtener todos los autores
	@GetMapping("/autores")
	public List<Autor> viewHomePage() {
		return autorservicio.getAllAutor();
	}
	
	//Obtener un autor por su ID
	@GetMapping("/{idAutor}")
	public Autor getAutorById(@PathVariable(value="idAutor") int idAutor){
	     return autorservicio.getAutorById(idAutor);
	}
	
	//Agregar un autor
	@PostMapping("/save")
	public String saveAutor(/*@RequestBody*/ @ModelAttribute("autor") Autor autor) {
		autorservicio.saveAutor(autor);
		return "Añadido correctamente";
	}
	
	//Eliminar un Autor
	@GetMapping("delete/{id}")
	public void delete(@PathVariable("id") int id) {
		autorservicio.deleteAutorById(id);		
	}
}
