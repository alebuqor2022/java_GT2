package com.indra.biblioteca.services;

import java.util.List;

import com.indra.biblioteca.model.Multa;

public interface MultaService {

	List<Multa> getAllMulta();
	void saveMulta(Multa multa);
	Multa getMultaById(int id);
	void deleteMultaById(int id);
	//Metodo para paginacion de los datos
	//Los parametros son:numero de pagina, tamaño de esa pagina,
	//porque campo lo ordeno y si es asc o desc
	//Page <Autor>findPaginated(int pageNum, int pageSize, String sortField,String sortDirection);

}
