package com.indra.biblioteca.services;

import java.util.List;


import com.indra.biblioteca.model.Copia;

public interface CopiaService {
	List<Copia> getAllCopia();
	void saveCopia(Copia copia);
	Copia getCopiaById(int id);
	void deleteCopiaById(int id);
	//Metodo para paginacion de los datos
	//Los parametros son:numero de pagina, tamaño de esa pagina,
	//porque campo lo ordeno y si es asc o desc
	//Page <Autor>findPaginated(int pageNum, int pageSize, String sortField,String sortDirection);

}
