package com.indra.biblioteca.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.biblioteca.model.Autor;
import com.indra.biblioteca.model.Multa;
import com.indra.biblioteca.repository.AutorRepository;
import com.indra.biblioteca.repository.MultaRepository;
@Service
public class MultaServiceImp implements MultaService{
	@Autowired
	private MultaRepository repositorioMulta;
	
	@Override
	public List<Multa> getAllMulta() {
		return repositorioMulta.findAll();
	}

	@Override
	public void saveMulta(Multa multa) {
		repositorioMulta.save(multa);
	}

	@Override
	public Multa getMultaById(int id) {
		Optional<Multa> optionalMulta=repositorioMulta.findById( id);
		Multa multa=null;
		if (optionalMulta.isPresent()) {
			multa=optionalMulta.get();
		}else {
			throw new RuntimeException("La multa no se encuentra");
		}
		return multa;
	}

	@Override
	public void deleteMultaById(int id) {
		repositorioMulta.deleteById(id);
	}
}
