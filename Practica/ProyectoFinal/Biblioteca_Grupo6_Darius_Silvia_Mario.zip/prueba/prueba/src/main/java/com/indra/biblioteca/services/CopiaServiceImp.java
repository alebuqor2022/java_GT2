package com.indra.biblioteca.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.biblioteca.model.Autor;
import com.indra.biblioteca.model.Copia;
import com.indra.biblioteca.repository.CopiaRepository;
@Service
public class CopiaServiceImp implements CopiaService{
	
	@Autowired
	private CopiaRepository repositorioCopia;
	@Override
	public List<Copia> getAllCopia() {
		return repositorioCopia.findAll();
	}

	@Override
	public void saveCopia(Copia copia) {
		repositorioCopia.save(copia);
	}

	@Override
	public Copia getCopiaById(int id) {
		Optional<Copia> optionalCopia=repositorioCopia.findById( id);
		Copia copia=null;
		if (optionalCopia.isPresent()) {
			copia=optionalCopia.get();
		}else {
			throw new RuntimeException("La Copia no se encuentra");
		}
		return copia;
	}

	@Override
	public void deleteCopiaById(int id) {
		repositorioCopia.deleteById(id);
	}

}
