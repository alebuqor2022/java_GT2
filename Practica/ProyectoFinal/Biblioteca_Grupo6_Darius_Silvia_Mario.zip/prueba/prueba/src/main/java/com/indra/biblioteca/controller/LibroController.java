package com.indra.biblioteca.controller;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.indra.biblioteca.model.Autor;
import com.indra.biblioteca.model.Libro;
import com.indra.biblioteca.services.AutorService;
import com.indra.biblioteca.services.LibroService;
import com.indra.biblioteca.services.LibroServiceImp;

@RestController
@RequestMapping(path="/libro")
public class LibroController {
    
    @Autowired
    private LibroService libroservicio;
    @Autowired 
    private AutorService autorservicio;
    
    //Obtener todos los libros
    @GetMapping(path=("/libros"))
    public List<Libro> getAlllibros() {
        return libroservicio.getAllLibros();
    }
    //Obtener un libro por su ISBN
    @GetMapping(path=("/libros/{ISBN}"))
    public Libro getlibro(@PathVariable(value="ISBN") int ISBN) {
        return libroservicio.getLibroById(ISBN);
    }
    //Agregar un libro
    @PostMapping(path="/save")
    public void saveLibro(/*@RequestBody*/@ModelAttribute("lectores") Libro libro) {
        libroservicio.saveLibro(libro);
    } 
    
    @Transactional
    //Eliminar un libro
    @GetMapping(path="/delete/{ISBN}")
    public void deleteLibro(@PathVariable(value="ISBN") int ISBN) {
        libroservicio.deleteLibroById(ISBN);
    }
    
   /* @GetMapping("/update/{ISBN}")
    public String showFormForUpdate(@PathVariable(value="ISBN") int ISBN, Model model) {
        Libro libro=libroservicio.getLibroById(ISBN);
        model.addAttribute("libro", libro);
        return "index.html";
    }
    
    @GetMapping("/add")
    public String showNewLibroForm(Model model) {
        Libro libro = new Libro();
        model.addAttribute("libro", libro);
        return "index.html";
        
    }*/
}