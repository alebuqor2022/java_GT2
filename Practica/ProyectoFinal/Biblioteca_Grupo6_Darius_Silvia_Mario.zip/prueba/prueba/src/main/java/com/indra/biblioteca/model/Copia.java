package com.indra.biblioteca.model;
import java.io.Serializable;
import java.util.Set;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
@Table(name="copia")
public class Copia implements Serializable{

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int idCopia;
    @Column(name="estado")
    @Enumerated(EnumType.STRING)
    private EstadoCopia estado;
    
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="libro",  referencedColumnName = "ISBN")
    private Libro libro;
    
    @Transient
    @OneToMany(fetch=FetchType.LAZY,mappedBy="copia",targetEntity=Prestamo.class,cascade=CascadeType.ALL,orphanRemoval = true)
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    @JoinColumn(name="copia",referencedColumnName = "idCopia")
    private Set<Prestamo> prestamo;
   
    public Copia() {
        super();
    }
    
    public Copia(int idCopia, EstadoCopia estado, Libro libro) {
        super();
        this.idCopia = idCopia;
        this.estado = estado;
        this.libro=libro;
    }
    
    public int getIdCopia() {
        return idCopia;
    }

   public void setIdCopia(int idCopia) {
        this.idCopia = idCopia;
    }

   public EstadoCopia getEstado() {
        return estado;
    }

   public void setEstado(EstadoCopia estado) {
        this.estado = estado;
    }

   public Libro getLibro() {
        return libro;
    }

   public void setLibro(Libro libro) {
        this.libro = libro;
    }
    
}