package com.indra.biblioteca.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.biblioteca.model.Lector;
import com.indra.biblioteca.repository.LectorRepository;
@Service
public class LectorServiceImp implements LectorService {
	 @Autowired
	  private LectorRepository repositorioLector;

	 @Override

	 public List<Lector> getAllLector() {
	    return repositorioLector.findAll();
	 }

	 @Override
	 public void saveLector(Lector lector) {
	    repositorioLector.save(lector);
	}
	   
	 @Override
	 public Lector getLectorById(int numeroSocio) {
	    Optional<Lector> optionalLector=repositorioLector.findById(numeroSocio);
	    Lector lector=null;
	    if (optionalLector.isPresent()) {
	        lector=optionalLector.get();
	    }else {
	        throw new RuntimeException("El lector no se encuentra");
	    }    
	    return lector;
	 }

	 @Override
	 public void deleteLectorById(int numeroSocio) {
	    repositorioLector.deleteById(numeroSocio);
	 }
}