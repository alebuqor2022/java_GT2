package com.indra.biblioteca.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.indra.biblioteca.model.Lector;
import com.indra.biblioteca.services.LectorService;

@RestController
@RequestMapping(path="/lector")
public class LectorController {
	  
    @Autowired
    private LectorService lectorservicio;
    
    //Obtener todos los lectores
    @GetMapping("/lectores")
    public List<Lector> getAllLectores(){
        return lectorservicio.getAllLector();
    }
    //Obtener un lector por su ID
    @GetMapping("/{numeroSocio}")
    public Lector getLectorById(@PathVariable(value="numeroSocio") int numeroSocio){
        return lectorservicio.getLectorById(numeroSocio);
    }
    //Agregar un lector
    @PostMapping("/save")
    public String saveLector(/*@RequestBody*/@ModelAttribute("lector")Lector lector) {
        lectorservicio.saveLector(lector);
    return "redirect:/";
    }
    //Eliminar un lector
    @GetMapping("/delete/{numeroSocio}")
    public void deleteLector(@PathVariable(value="numeroSocio") int numeroSocio) {
        this.lectorservicio.deleteLectorById(numeroSocio);
       
    }
    /*
    @GetMapping("/update/{numeroSocio}")
    public String showFormForUpdate(@PathVariable(value="numeroSocio") int numeroSocio, Model model) {
        Lector lector=lectorservicio.getLectorById(numeroSocio);
        model.addAttribute("lector", lector);
        return "index.html";
    }*/
    

}
