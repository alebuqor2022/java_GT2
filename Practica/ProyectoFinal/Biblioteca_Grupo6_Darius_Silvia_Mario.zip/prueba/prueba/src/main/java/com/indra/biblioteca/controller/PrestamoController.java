package com.indra.biblioteca.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.indra.biblioteca.model.Autor;
import com.indra.biblioteca.model.Lector;
import com.indra.biblioteca.model.Prestamo;
import com.indra.biblioteca.services.AutorService;
import com.indra.biblioteca.services.PrestamoService;

@RestController
@RequestMapping(path="/prestamo")
public class PrestamoController {
	
	@Autowired
	private PrestamoService prestamoservicio;

	//Obtener todos los prestamos
	@GetMapping("/prestamos")
	public List<Prestamo> getAllPrestamos() {
		return prestamoservicio.getAllPrestamo();
	}
	//Obtener un prestamo por su ID
	@GetMapping("/{idPrestamo}")
	public Prestamo getPrestamoById(@PathVariable(value="idPrestamo") int idPrestamo){
	     return prestamoservicio.getPrestamoById(idPrestamo);
	}
	//Agregar un prestamo
	@PostMapping("/save")
	public void saveAutor(@RequestBody Prestamo prestamo) {
		prestamoservicio.savePrestamo(prestamo);
	}
	
	//Eliminar un prestamo
	@GetMapping(path={"delete/{id}"})
	public void delete(@PathVariable("id") int id) {
		prestamoservicio.deletePrestamoById(id);		
	}
}
