package com.indra.biblioteca.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.biblioteca.model.Prestamo;
import com.indra.biblioteca.repository.PrestamoRepository;
@Service
public class PrestamoServiceImp implements PrestamoService{
	
	@Autowired
	private PrestamoRepository repositorioPrestamo;
	
	
	@Override
	public List<Prestamo> getAllPrestamo() {
		return repositorioPrestamo.findAll();
	}

	@Override
	public void savePrestamo(Prestamo prestamo) {
		repositorioPrestamo.save(prestamo);
	}

	@Override
	public Prestamo getPrestamoById(int id) {
        Optional<Prestamo> optionalPrestamo=repositorioPrestamo.findById(id);
        Prestamo prestamo=null;
        if (optionalPrestamo.isPresent()) {
        	prestamo=optionalPrestamo.get();
        }else {
            throw new RuntimeException("El prestamo no se encuentra");
        }
        return prestamo;
	}

	@Override
	public void deletePrestamoById(int id) {
		repositorioPrestamo.deleteById(id);
	}
}
