package com.indra.biblioteca.model;

public enum EstadoCopia {
	PRESTADO,RETRASADO,BIBLIOTECA,REPARACION
}
