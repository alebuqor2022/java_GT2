package com.indra.biblioteca.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.biblioteca.model.Autor;
import com.indra.biblioteca.repository.AutorRepository;

@Service
public class AutorServiceImp implements AutorService{
	
	@Autowired
	private AutorRepository repositorioAutor;
	
	@Override
	public List<Autor> getAllAutor() {
		return repositorioAutor.findAll();	 
	}

	@Override
	public void saveAutor(Autor autor) {
		repositorioAutor.save(autor);
	}

	@Override
	public Autor getAutorById(int id) {
		Optional<Autor> optionalAutor=repositorioAutor.findById( id);
		Autor autor=null;
		if (optionalAutor.isPresent()) {
			autor=optionalAutor.get();
		}else {
			throw new RuntimeException("El autor no se encuentra");
		}
		return autor;
	}
	
	@Override
	public void deleteAutorById(int id) {
		repositorioAutor.deleteById(id);	
	}
}
