package com.indra.biblioteca.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.indra.biblioteca.model.Copia;
import com.indra.biblioteca.services.CopiaService;

@RestController
@RequestMapping(path="/copia")
public class CopiaController {
	
	@Autowired
	private CopiaService copiaservicio;

	
	//Obtener todas las copias
	@GetMapping(path="/copias")
	public List<Copia> getAllCopias() {
		return copiaservicio.getAllCopia();
	}
	
	//Obtener una copia por su ID
	@GetMapping(path="/{idCopia}")
	public Copia getCopiasById(@PathVariable("idCopia") int idCopia) {
		return copiaservicio.getCopiaById(idCopia);
	}
	
	//Agregar una copia
	@PostMapping(path="/save")
	public void saveAutor(@RequestBody Copia copia) {
		copiaservicio.saveCopia(copia);
	}
	
	//Eliminar una copia
	@GetMapping(path={"delete/{id}"})
	public void delete(@PathVariable("id") int id) {
		copiaservicio.deleteCopiaById(id);		
	}
}
