package com.indra.biblioteca.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.indra.biblioteca.model.Multa;
import com.indra.biblioteca.services.LectorService;
import com.indra.biblioteca.services.MultaService; 

@RestController
@RequestMapping(path="/multa")
public class MultaController {

	@Autowired
	private MultaService multaservicio;
	@Autowired
	private LectorService lectorservicio;
	
	//Obtener todas las multas
	@GetMapping(path="/multas")
	public List<Multa> getAllMultas() {
		return multaservicio.getAllMulta();
	}
	//Obtener una multa por su ID
	@GetMapping(path="/{idMulta}")
	public Multa getMultaById(@PathVariable("idMulta") int idMulta) {
		return multaservicio.getMultaById(idMulta);
	}
	
	//Agregar una multa
	@PostMapping(path="/save")
	public void saveMulta(@RequestBody Multa multa) {
		multaservicio.saveMulta(multa);
	}
	
	//@Transactional
	//Eliminar una multa
	@RequestMapping(method=RequestMethod.GET,value="delete/{id}")
	public void delete(@PathVariable("id") int id) {
		multaservicio.deleteMultaById(id);		
	}
}
