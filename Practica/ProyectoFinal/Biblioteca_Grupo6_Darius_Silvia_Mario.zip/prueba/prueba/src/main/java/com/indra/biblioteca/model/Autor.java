package com.indra.biblioteca.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
@Table(name="autor")
public class Autor implements Serializable{

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int idAutor;
    @Column(name="nombre")
    private String nombre;
    @Column(name="nacionalidad")
    private String nacionalidad;
    @Column(name="fechaNacimiento")
    private Date fechaNacimiento;

    @Transient//se pone solo en esta, en la de libros no hace falta
    @OneToMany(fetch=FetchType.LAZY,mappedBy="autor",targetEntity=Libro.class,cascade=CascadeType.ALL,orphanRemoval = true)
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    @JoinColumn(name="autor",referencedColumnName = "idAutor")
    private Set<Libro> libros;

    public Autor() {
		super();
	}

	public Autor(int idAutor, String nombre, String nacionalidad, Date fechaNacimiento, Set<Libro> libros) {
	      super();
	      this.idAutor = idAutor;
	      this.nombre = nombre;
	      this.nacionalidad = nacionalidad;
	      this.fechaNacimiento = fechaNacimiento;
	      this.libros = libros;
	}

   public int getIdAutor() {
        return idAutor;
    }

   public void setIdAutor(int idAutor) {
        this.idAutor = idAutor;
    }

   public String getNombre() {
        return nombre;
    }


   public void setNombre(String nombre) {
        this.nombre = nombre;
    }

   public String getNacionalidad() {
        return nacionalidad;
    }

   public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

   public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

   public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

   public Set<Libro> getLibros() {
        return libros;
    }

   public void setLibros(Set<Libro> libros) {
        this.libros = libros;
    }

}