package com.indra.biblioteca.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
@Table(name="prestamo")
public class Prestamo implements Serializable{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idPrestamo;
	@Column(name="inicio")
	private Date inicio;
	@Column(name="fin")
	private Date fin;
	
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="copia")
	private Copia copia;
    
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="lector")
	private Lector lector;
	
	public Prestamo() {
		super();
	}

	public Prestamo(int idPrestamo, Date inicio, Date fin, Copia copia,Lector lector) {
		super();
		this.idPrestamo = idPrestamo;
		this.inicio = inicio;
		this.fin = fin;
		this.copia = copia;
		this.lector = lector;
	}

	public int getIdPrestamo() {
		return idPrestamo;
	}
	
	public void setIdPrestamo(int idPrestamo) {
		this.idPrestamo = idPrestamo;
	}
	
	public Date getInicio() {
		return inicio;
	}
	
	public void setInicio(Date inicio) {
		this.inicio = inicio;
	}
	
	public Date getFin() {
		return fin;
	}
	
	public void setFin(Date fin) {
		this.fin = fin;
	}

	public Copia getCopia() {
		return copia;
	}

	public void setCopia(Copia copia) {
		this.copia = copia;
	}

	public Lector getLector() {
		return lector;
	}

	public void setLector(Lector lector) {
		this.lector = lector;
	}
}
