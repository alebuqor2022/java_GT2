package com.indra.biblioteca.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.*;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.indra.biblioteca.model.*;
import com.indra.biblioteca.services.AutorService;
import com.indra.biblioteca.services.CopiaService;
import com.indra.biblioteca.services.LectorService;
import com.indra.biblioteca.services.LibroService;
import com.indra.biblioteca.services.PrestamoService;


@Controller
public class ControllerPrincipal {
	@Autowired
	private AutorService autorservicio;
	
	@Autowired
	private LibroService libroservicio;
	
	@Autowired
    private LectorService lectorservicio;
	
	@Autowired
	private CopiaService copiaservicio;
	
	@Autowired
	private PrestamoService prestamoservicio;
	
	@GetMapping("/")
	public String viewHomePage(Model model) {
		return "index.html";
	}
	@GetMapping("/libroall")
	public String getAllLibros(Model model) {
		List<Libro> libros=libroservicio.getAllLibros();
		model.addAttribute("listalibros", libros);
		return "Libro";
		
	}
	@GetMapping("/autoresall")
	public String getAllAutores(Model model) {
		List<Autor> autores=autorservicio.getAllAutor();
        model.addAttribute("listAutores", autores);
		return "Autores";
		
	}
	@GetMapping("/lectorall")
	public String getAllLectores(Model model) {
		List<Lector> listalector=lectorservicio.getAllLector();
		model.addAttribute("lectores", listalector);
		return "Lector";
		
	}
	
	@GetMapping("/prestamosall")
	public String showNewPrestamoForm(Model model){
	    List<Prestamo> prestamo=prestamoservicio.getAllPrestamo();
	    model.addAttribute("listPrestamos", prestamo);  
	    return "prestamos";
	}
	
	@GetMapping("/add")
	public String showNewCursoForm(Model model) {
		Autor autor = new Autor();
		model.addAttribute("autor", autor);
		Libro libro = new Libro();
		model.addAttribute("libro", libro);
		Lector lector = new Lector();
		model.addAttribute("lector", lector);
		return "Agregar";
	}
	
	@GetMapping("/update/autor/{idAutor}")
	public String showFormForUpdate(@PathVariable(value="idAutor") int idAutor, Model model) {
	    Autor autor=new Autor();
	    autor=autorservicio.getAutorById(idAutor);
	    model.addAttribute("autor", autor);
	    return "update";
	}
	
	@GetMapping("/update/lector/{numeroSocio}")
    public String updateLector(@PathVariable(value="numeroSocio") int numeroSocio, Model model) {
        Lector lector=new Lector();
        lector=lectorservicio.getLectorById(numeroSocio);
        model.addAttribute("lector", lector);
        return "updateLector";
    }
	
	  @GetMapping("/update/libro/{ISBN}")
	    public String updateLibro(@PathVariable(value="ISBN") int ISBN, Model model) {
	        Libro libro=new Libro();
	        libro=libroservicio.getLibroById(ISBN);
	        model.addAttribute("libro", libro);
	        return "updateLibro";
	    }
	  
	  
	  
	  
	//Obtener todas las copias
	  @GetMapping("/copiasAll")
	    public String getAllCopias(Model model) {
	        List<Copia> copias=copiaservicio.getAllCopia();
	        model.addAttribute("listCopias", copias);
	        
	        return "copiasLibro";
	    }
}
