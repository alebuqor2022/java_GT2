package com.indra.biblioteca.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.biblioteca.model.Libro;
import com.indra.biblioteca.repository.LibroRepository;
@Service
public class LibroServiceImp implements LibroService {
	   @Autowired
	    //La interfaz que se comunica con la BD
	    private LibroRepository repositorioLibro;
	   @Override
		public List<Libro> getAllLibros() {
			
			return  repositorioLibro.findAll();
		}
	   
	  @Override
	    public void saveLibro(Libro libro) {
	        repositorioLibro.save(libro);
	    }

	  @Override
	    public Libro getLibroById(int ISBN) {
	        Optional<Libro> optionalLibro=repositorioLibro.findById(ISBN);
	        Libro libro=null;
	        if (optionalLibro.isPresent()) {
	            libro=optionalLibro.get();
	        }else {
	            throw new RuntimeException("El libro no se encuentra"); 
	        }
	        return libro;
	    }
	  @Override
	    public void deleteLibroById(int ISBN) {
	        repositorioLibro.deleteById(ISBN);
	    }

	}