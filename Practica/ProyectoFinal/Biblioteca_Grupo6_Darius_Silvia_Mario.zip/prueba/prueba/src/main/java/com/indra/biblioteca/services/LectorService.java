package com.indra.biblioteca.services;

import java.util.List;

import com.indra.biblioteca.model.Autor;
import com.indra.biblioteca.model.Lector;

public interface LectorService {

	List<Lector> getAllLector();
	void saveLector(Lector lector);
	Lector getLectorById(int id);
	void deleteLectorById(int id);
	//Metodo para paginacion de los datos
	//Los parametros son:numero de pagina, tamaño de esa pagina,
	//porque campo lo ordeno y si es asc o desc
	//Page <Autor>findPaginated(int pageNum, int pageSize, String sortField,String sortDirection);

}
