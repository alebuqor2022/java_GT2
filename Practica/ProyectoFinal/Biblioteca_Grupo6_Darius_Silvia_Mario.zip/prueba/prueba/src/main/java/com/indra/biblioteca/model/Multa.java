package com.indra.biblioteca.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity 
@Table(name="multa")
public class Multa implements Serializable{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idMulta;
	@Column(name="inicio")
	private Date inicio;
	@Column(name="fin")
	private Date fin;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@JoinColumn(name="lector")
	private Lector lector;
	
	public Multa() {
		super();
	}
	
	public Multa(int idMulta, Date inicio, Date fin, Lector lector) {
		super();
		this.idMulta = idMulta;
		this.inicio = inicio;
		this.fin = fin;
		this.lector = lector;
	}

	public int getIdMulta() {
		return idMulta;
	}
	
	public void setIdMulta(int idMulta) {
		this.idMulta = idMulta;
	}
	
	public Date getInicio() {
		return inicio;
	}
	
	public void setInicio(Date inicio) {
		this.inicio = inicio;
	}
	
	public Date getFin() {
		return fin;
	}
	
	public void setFin(Date fin) {
		this.fin = fin;
	}

	public Lector getLector() {
		return lector;
	}

	public void setLector(Lector lector) {
		this.lector = lector;
	}
}
