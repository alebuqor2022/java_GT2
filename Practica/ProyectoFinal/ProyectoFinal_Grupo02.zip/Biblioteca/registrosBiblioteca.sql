
-- insert estado_copia
INSERT INTO `indragt22`.`estado_copia` (`nombre`) VALUES ('Prestado');
INSERT INTO `indragt22`.`estado_copia` (`nombre`) VALUES ('Retraso');
INSERT INTO `indragt22`.`estado_copia` (`nombre`) VALUES ('Biblioteca');
INSERT INTO `indragt22`.`estado_copia` (`nombre`) VALUES ('Reparacion');

-- insert autores
INSERT INTO `indragt22`.`autor` (`fecha_nacimiento`, `nacionalidad`, `nombre`) VALUES ('1547-09-29', 'España', 'Miguel de Cervantes');
INSERT INTO `indragt22`.`autor` (`fecha_nacimiento`, `nacionalidad`, `nombre`) VALUES ('1616-04-23', 'Reino Unido', 'Willam Shakespeare');
INSERT INTO `indragt22`.`autor` (`fecha_nacimiento`, `nacionalidad`, `nombre`) VALUES ('1947-09-21', 'Estados Unidos', 'Stephen King');
INSERT INTO `indragt22`.`autor` (`fecha_nacimiento`, `nacionalidad`, `nombre`) VALUES ('1961-07-21', 'Estados Unidos', 'Ernest Hemingway');

-- insert Libros
INSERT INTO `indragt22`.`libro` (`anyo`, `editorial`, `tipo_libro`, `titulo`, `autor`) VALUES ('1615', 'Imprenta de Juan de la Cuesta', 'novela', 'Don Quijote de la Mancha', '1');
INSERT INTO `indragt22`.`libro` (`anyo`, `editorial`, `tipo_libro`, `titulo`, `autor`) VALUES ('1977', 'Doubleday ', 'novela', 'El Resplandor', '3');
INSERT INTO `indragt22`.`libro` (`anyo`, `editorial`, `tipo_libro`, `titulo`, `autor`) VALUES ('1974', 'Pomaire', 'novela', 'Carrie', '3');
INSERT INTO `indragt22`.`libro` (`anyo`, `editorial`, `tipo_libro`, `titulo`, `autor`) VALUES ('1613', 'Mojito de Uruguay', 'novela', 'Novelas ejemplares', '1');
INSERT INTO `indragt22`.`libro` (`anyo`, `editorial`, `tipo_libro`, `titulo`, `autor`) VALUES ('1585', 'Espasa', 'novela', 'La Galatea', '1');
INSERT INTO `indragt22`.`libro` (`anyo`, `editorial`, `tipo_libro`, `titulo`, `autor`) VALUES ('1597', 'Alfaguara', 'teatro', 'Romeo y Julieta', '2');
INSERT INTO `indragt22`.`libro` (`anyo`, `editorial`, `tipo_libro`, `titulo`, `autor`) VALUES ('1602', 'Alianza Editorial', 'teatro', 'Hamlet', '2');
INSERT INTO `indragt22`.`libro` (`anyo`, `editorial`, `tipo_libro`, `titulo`, `autor`) VALUES ('1986', 'Signet books', 'novela', 'It', '3');

-- insert copias
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('1', '1');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('2', '1');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('3', '2');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('4', '3');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('5', '4');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('6', '4');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('7', '4');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('8', '2');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('1', '2');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('2', '2');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('3', '1');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('4', '1');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('5', '1');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('6', '3');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('7', '3');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('8', '3');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('1', '3');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('1', '3');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('2', '3');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('2', '3');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('3', '2');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('4', '4');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('4', '1');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('6', '1');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('6', '1');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('8', '1');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('5', '2');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('8', '3');
INSERT INTO `indragt22`.`copia` (`libro`, `estado_copia`) VALUES ('3', '3');

-- insert lector

INSERT INTO `indragt22`.`lector` (`direccion`, `nombre`, `telefono`) VALUES ('Calle barco', 'Antonio Carmona', '600810806');
INSERT INTO `indragt22`.`lector` (`direccion`, `nombre`, `telefono`) VALUES ('calle garibaldi', 'Sergi Perez', '634567234');
INSERT INTO `indragt22`.`lector` (`direccion`, `nombre`, `telefono`) VALUES ('calle girona', 'Alex Garcilaso', '602934582');
INSERT INTO `indragt22`.`lector` (`direccion`, `nombre`, `telefono`) VALUES ('calle roser', 'Raul Gomez', '632019234');
INSERT INTO `indragt22`.`lector` (`direccion`, `nombre`, `telefono`) VALUES ('calle planta', 'Izan Gallardo', '648203123');

-- insert prestamos
INSERT INTO `indragt22`.`prestamo` (`fin`, `inicio`, `copia`, `lector`) VALUES ('2022-11-30', '2022-11-01', '31', '2');
INSERT INTO `indragt22`.`prestamo` (`fin`, `inicio`, `copia`, `lector`) VALUES ('2022-11-30', '2022-11-01', '32', '2');
INSERT INTO `indragt22`.`prestamo` (`fin`, `inicio`, `copia`, `lector`) VALUES ('2022-11-30', '2022-11-01', '33', '2');




