Prerrequisitos de instalación: 

- Maven.
- SpringBoot.
- JUnit testing (opcional).
- Base de datos MySQL.
- Thymeleaf.
- Eclipse IDE (última versión).

