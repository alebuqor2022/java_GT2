package com.indra.Biblioteca.service;

import java.util.List;

import com.indra.Biblioteca.model.estadoCopia;

public interface estadoCopiaService {

	void saveEstadoCopia(estadoCopia estadoCopia);
	List<estadoCopia>listEstadoCopia();
}
