package com.indra.Biblioteca.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Copia")
public class Copia {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "estadoCopia")
	private estadoCopia estadoCopia;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "Libro")
	private Libro Libro;

	@OneToOne(mappedBy = "Copia", targetEntity = Prestamo.class, cascade = CascadeType.ALL)
	private Prestamo Prestamo;


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public estadoCopia getEstadoCopia() {
		return estadoCopia;
	}

	public void setEstadoCopia(estadoCopia estadoCopia) {
		this.estadoCopia = estadoCopia;
	}

	public Libro getLibro() {
		return Libro;
	}

	public void setLibro(Libro libro) {
		Libro = libro;
	}

}
