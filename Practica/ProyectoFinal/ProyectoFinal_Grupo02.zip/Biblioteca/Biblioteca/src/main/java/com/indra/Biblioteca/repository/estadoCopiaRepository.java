package com.indra.Biblioteca.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.indra.Biblioteca.model.Autor;
import com.indra.Biblioteca.model.estadoCopia;

public interface estadoCopiaRepository extends JpaRepository<estadoCopia, Long>{

}
