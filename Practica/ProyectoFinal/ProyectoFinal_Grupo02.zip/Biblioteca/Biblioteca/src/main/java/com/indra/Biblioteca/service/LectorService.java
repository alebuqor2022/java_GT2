package com.indra.Biblioteca.service;

import java.util.List;

import com.indra.Biblioteca.model.Lector;

public interface LectorService {
	void saveLector(Lector Lector);
	List<Lector> listaLectores();
}
