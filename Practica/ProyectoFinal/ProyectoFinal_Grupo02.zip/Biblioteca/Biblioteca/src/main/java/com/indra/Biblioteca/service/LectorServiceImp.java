package com.indra.Biblioteca.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.Biblioteca.model.Lector;
import com.indra.Biblioteca.repository.LectorRepository;

@Service
public class LectorServiceImp implements LectorService{

	@Autowired 
	private LectorRepository repositorio;


	@Override
	public void saveLector(Lector Lector) {
		this.repositorio.save(Lector);
	}

	@Override
	public List<Lector> listaLectores() {
		// TODO Auto-generated method stub
		return this.repositorio.findAll();
	}
	
	
}
