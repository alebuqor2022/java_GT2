package com.indra.Biblioteca.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.Biblioteca.model.Copia;
import com.indra.Biblioteca.model.Prestamo;
import com.indra.Biblioteca.repository.PrestamoRepository;


@Service
public class PrestamoServiceImp implements PrestamoService{
	
	@Autowired 
	private PrestamoRepository repositorio;
	
	@Override
	public List<Prestamo> listarPrestamo() {
		return this.repositorio.findAll();
	}
	
	@Override
	public void savePrestamo(Prestamo Prestamo) {
		this.repositorio.save(Prestamo);
	}
	
	@Override
	public Prestamo getPrestamoById(Long id) {
		
		return this.repositorio.PrestamobyId(id);
	}

	@Override
	public List<Prestamo> listPrestamobyCopia(long id) {
		// TODO Auto-generated method stub
		return this.repositorio.listPrestamobyCopia(id);
	}

}
