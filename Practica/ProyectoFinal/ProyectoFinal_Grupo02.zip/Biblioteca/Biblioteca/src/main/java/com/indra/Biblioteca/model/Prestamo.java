package com.indra.Biblioteca.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="Prestamo")
public class Prestamo {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column
	@Temporal(TemporalType.DATE)
	private Date inicio;
	
	@Column
	@Temporal(TemporalType.DATE)
	private Date fin;
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="Copia")
	private Copia Copia;
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="Lector")
	private Lector Lector;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getInicio() {
		return inicio;
	}

	public void setInicio(Date inicio) {
		this.inicio = inicio;
	}

	public Date getFin() {
		return fin;
	}

	public void setFin(Date fin) {
		this.fin = fin;
	}

	public Copia getCopia() {
		return Copia;
	}

	public void setCopia(Copia copia) {
		Copia = copia;
	}

	public Lector getLector() {
		return Lector;
	}

	public void setLector(Lector lector) {
		Lector = lector;
	}
	
	
	
}
