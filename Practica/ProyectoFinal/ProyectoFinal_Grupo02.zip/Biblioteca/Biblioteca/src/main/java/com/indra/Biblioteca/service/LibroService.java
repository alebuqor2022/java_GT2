package com.indra.Biblioteca.service;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.indra.Biblioteca.model.Autor;
import com.indra.Biblioteca.model.Libro;




public interface LibroService {
	
	List<Libro> listar();
	void saveLibro(Libro Libro);
	void deleteLibrobyId(long id);
	Libro getLibrobyId(long id);
	List<Libro> findLibrobyAutor(String id);
	
}
