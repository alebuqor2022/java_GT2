package com.indra.Biblioteca.service;

import java.util.List;

import com.indra.Biblioteca.model.Autor;


public interface AutorService {
	List<Autor> listarAutor();
}
