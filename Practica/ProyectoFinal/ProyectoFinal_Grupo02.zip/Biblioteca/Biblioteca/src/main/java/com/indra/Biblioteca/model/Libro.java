package com.indra.Biblioteca.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Libro")
public class Libro {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column
	private String titulo;
	
	@Column
	private String editorial;
	
	@Column
	private int anyo;
	
	@Column
	private String tipoLibro;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="autor")
	private Autor Autor;
	
	@OneToMany(mappedBy="Libro", targetEntity=Copia.class, cascade=CascadeType.ALL)
	private Set<Copia> Copia;


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getTipoLibro() {
		return tipoLibro;
	}

	public void setTipoLibro(String tipoLibro) {
		this.tipoLibro = tipoLibro;
	}

	public String getEditorial() {
		return editorial;
	}

	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}

	public int getAnyo() {
		return anyo;
	}

	public void setAnyo(int anyo) {
		this.anyo = anyo;
	}

	public Autor getAutor() {
		return Autor;
	}

	public void setAutor(Autor autor) {
		Autor = autor;
	}

	public Set<Copia> getCopia() {
		return Copia;
	}

	public void setCopia(Set<Copia> copia) {
		Copia = copia;
	}

}
