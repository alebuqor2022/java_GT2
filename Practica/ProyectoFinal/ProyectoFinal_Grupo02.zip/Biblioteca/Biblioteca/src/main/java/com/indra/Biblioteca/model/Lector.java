package com.indra.Biblioteca.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Lector")
public class Lector {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long nSocio;
	
	@Column
	private String nombre;
	@Column
	private String telefono;
	@Column
	private String direccion;
	
	@OneToMany(mappedBy="Lector", targetEntity=Prestamo.class, cascade=CascadeType.ALL)
	private Set<Prestamo> Prestamo;
	
	@OneToOne(mappedBy="Lector", targetEntity=Multa.class, cascade=CascadeType.ALL)
	private Multa Multa;
	
	
	public void devolver( Long nSocio, Date fechaAct) {
		
		//comprobar si cuando lo devuelve ha pasado 1 mes, se hace una multa. 
	}

	public void prestar(Long nSocio, Date fechaAct) {
		
		//comprueba si cuando va a prestar el libro tiene una multa.
	}
	
	public void multar(int dias) {
		
	}
	
	public Multa getMulta() {
		return Multa;
	}

	public void setMulta(Multa multa) {
		Multa = multa;
	}

	public Long getnSocio() {
		return nSocio;
	}

	public void setnSocio(Long nSocio) {
		this.nSocio = nSocio;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public Set<Prestamo> getPrestamo() {
		return Prestamo;
	}

	public void setPrestamo(Set<Prestamo> prestamo) {
		Prestamo = prestamo;
	}
	
	
}
