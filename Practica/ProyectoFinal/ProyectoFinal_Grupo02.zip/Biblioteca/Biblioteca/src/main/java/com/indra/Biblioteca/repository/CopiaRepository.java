package com.indra.Biblioteca.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.indra.Biblioteca.model.Autor;
import com.indra.Biblioteca.model.Copia;
import com.indra.Biblioteca.model.Libro;

public interface CopiaRepository extends JpaRepository<Copia, Long>{

	@Query(value="select * from copia where estado_copia = 3 group by libro",nativeQuery = true)
	List<Copia> listarCopia();
	
	@Query(value="select * from copia where libro = :libro",nativeQuery = true)
	List<Copia> listCopiabyLibro(@Param("libro")long id);
	
	@Query(value="select * from copia where libro = :libro AND estado_copia = 3;",nativeQuery = true)
	List<Copia> listCopiabyLibroByEstado(@Param("libro")long id);
	
	@Query(value="select * from copia where estado_copia = 1 group by libro",nativeQuery = true)
	List<Copia> listarCopiaPrestado();
	
	@Query(value="select * from copia where libro = :libro AND estado_copia = 1;",nativeQuery = true)
	List<Copia> listCopiabyLibroByEstadoPrestado(@Param("libro")long id);

	
}
