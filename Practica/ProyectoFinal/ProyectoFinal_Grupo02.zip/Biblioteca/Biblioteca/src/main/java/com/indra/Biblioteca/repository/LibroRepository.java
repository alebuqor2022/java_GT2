package com.indra.Biblioteca.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.indra.Biblioteca.model.Autor;
import com.indra.Biblioteca.model.Libro;

public interface LibroRepository extends JpaRepository<Libro, Long>{
	
	@Query(value="Select l.* from libro l where l.autor = :autor",nativeQuery=true)
	List<Libro> findLibrobyAutor(@Param("autor")String long1);
}
