package com.indra.Biblioteca.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.indra.Biblioteca.model.Autor;
import com.indra.Biblioteca.model.Multa;

public interface MultaRepository extends JpaRepository<Multa, Long>{

}
