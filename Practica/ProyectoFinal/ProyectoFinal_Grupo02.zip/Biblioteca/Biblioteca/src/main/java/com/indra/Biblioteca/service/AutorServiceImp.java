package com.indra.Biblioteca.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.Biblioteca.model.Autor;
import com.indra.Biblioteca.repository.AutorRepository;


@Service
public class AutorServiceImp implements AutorService{

	@Autowired 
	private AutorRepository repositorio;
	
	
	@Override
	public List<Autor> listarAutor() {
		return this.repositorio.findAll();
	}
}
