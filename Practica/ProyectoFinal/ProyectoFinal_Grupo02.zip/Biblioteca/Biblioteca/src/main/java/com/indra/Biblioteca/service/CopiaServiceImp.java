package com.indra.Biblioteca.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.Biblioteca.model.Copia;
import com.indra.Biblioteca.model.Lector;
import com.indra.Biblioteca.repository.CopiaRepository;


@Service
public class CopiaServiceImp implements CopiaService{

	@Autowired 
	private CopiaRepository repositorio;
	
	@Override
	public void saveCopia(Copia Copia) {
		this.repositorio.save(Copia);
	}
	
	@Override
	public List<Copia> listarCopia() {
		return this.repositorio.listarCopia();
	}

	@Override
	public List<Copia> listCopiabyLibro(long id) {
		return this.repositorio.listCopiabyLibro(id);
	}

	@Override
	public List<Copia> listCopiabyLibroByEstado(long id) {
		return this.repositorio.listCopiabyLibroByEstado(id);
	}

	@Override
	public List<Copia> listarCopiaPrestado() {
		// TODO Auto-generated method stub
		return this.repositorio.listarCopiaPrestado();
	}

	@Override
	public List<Copia> listCopiabyLibroByEstadoPrestado(long id) {
		return this.repositorio.listCopiabyLibroByEstadoPrestado(id);
	}

}
