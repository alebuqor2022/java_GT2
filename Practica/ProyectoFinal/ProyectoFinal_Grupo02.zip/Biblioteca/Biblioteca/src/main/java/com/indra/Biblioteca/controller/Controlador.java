package com.indra.Biblioteca.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.thymeleaf.expression.Lists;

import com.indra.Biblioteca.model.Autor;
import com.indra.Biblioteca.model.Copia;
import com.indra.Biblioteca.model.Lector;
import com.indra.Biblioteca.model.Libro;
import com.indra.Biblioteca.model.Prestamo;
import com.indra.Biblioteca.model.estadoCopia;
import com.indra.Biblioteca.repository.LibroRepository;
import com.indra.Biblioteca.service.AutorService;
import com.indra.Biblioteca.service.CopiaService;
import com.indra.Biblioteca.service.LectorService;
import com.indra.Biblioteca.service.LibroService;
import com.indra.Biblioteca.service.PrestamoService;
import com.indra.Biblioteca.service.estadoCopiaService;



@Controller
public class Controlador {

	@Autowired
	private LibroService LService;

	@Autowired
	private AutorService AService;
	
	@Autowired
	private CopiaService CService;
	
	@Autowired
	private PrestamoService PService;
	
	@Autowired
	private LectorService LecService;
	
	@Autowired
	private estadoCopiaService esCService;

	@GetMapping("/")
	public String viewHomePage(Model model) {
		
		List<Libro> listLibros = LService.listar();
		List<Copia> listCopias = CService.listarCopia();
		List<Copia> listCopiasPrestado = CService.listarCopiaPrestado();
		
		model.addAttribute("listLibros", listLibros);
		model.addAttribute("listCopias", listCopias);
		model.addAttribute("listCopiasPrestado", listCopiasPrestado);
		return "index";
	}

	@GetMapping("/addLibro")
	public String showNewLibroForm(Model model) {
		List<Autor> listAutores = AService.listarAutor();
		Libro libro = new Libro();
		model.addAttribute("listAutores", listAutores);
		model.addAttribute("Libro", libro);
		return "addLibro";

	}
	
	@GetMapping("/addLector")
	public String showNewLectorForm(Model model) {
		Lector lector = new Lector();
		model.addAttribute("Lector", lector);
		return "addLector";
	}
	
	@GetMapping("/addCopia")
	public String showNewCopiaForm(Model model) {
		List<Libro> listLibros = LService.listar();
		List<estadoCopia> listEstadoCopia = esCService.listEstadoCopia();
		Copia Copia = new Copia();
		model.addAttribute("Copia", Copia);
		model.addAttribute("listEstadoCopia", listEstadoCopia);
		model.addAttribute("listLibros", listLibros);
		return "addCopia";
	}
	
	@GetMapping("/prestarLibro/{id}")
	public String showNewPrestarLibroForm(@PathVariable(value="id") long id, Model model) {
		List<Copia> listCopias = CService.listCopiabyLibro(id);
		List<Prestamo> listPrestamos = PService.listarPrestamo();
		List<Lector> listLectores = LecService.listaLectores();
		ArrayList<Lector> lista= new ArrayList<Lector>();
		List<Copia>  listCopiasByestado= CService.listCopiabyLibroByEstado(id);
		Prestamo Prestamo = new Prestamo();
		for(Lector l: listLectores) {
			int cont = 0;
			for(Prestamo p1 : listPrestamos) {
				if(p1.getLector().getNombre().equals(l.getNombre())){
					cont ++;
				}
			}
			if(cont<3){
				lista.add(l);
			}
		}
		model.addAttribute("listCopiasByestado",listCopiasByestado);
		model.addAttribute("listCopias",listCopias);
		model.addAttribute("listLector",lista);
		model.addAttribute("Prestamo",Prestamo);
		return "prestarLibro";
	}
	
	//devolver libro no acabado
	@GetMapping("/devolverLibro/{id}")
	public String showNewdevolverLibroForm(@PathVariable(value="id") long id, Model model) {
		List<Prestamo> listPrestamos = PService.listarPrestamo();
		List<Lector> listLectores = LecService.listaLectores();
		ArrayList<Lector> lista= new ArrayList<Lector>();
		List<Copia>  listCopiasByestadoPrestado= CService.listCopiabyLibroByEstadoPrestado(id);
		List<Prestamo> listPrestamobyCopia= PService.listPrestamobyCopia(id);
		Long Prestamo = (long) 0;
		model.addAttribute("listPrestamobyCopia",listPrestamobyCopia);
		model.addAttribute("Prestamo",Prestamo);
		return "devolverLibro";
	}
	
	@PostMapping("/saveLibro")
	public String saveLibro(@ModelAttribute("Libro") Libro Libro) {
		LService.saveLibro(Libro);
		return "redirect:/";
	}
	
	@PostMapping("/saveLector")
	public String saveLector(@ModelAttribute("Lector") Lector Lector) {
		LecService.saveLector(Lector);
		return "redirect:/";
	}
	
	@PostMapping("/saveCopia")
	public String saveCopia(@ModelAttribute("Copia") Copia Copia) {
		CService.saveCopia(Copia);
		return "redirect:/";
	}
	
	@PostMapping("/savePrestamo")
	public String savePrestamo(@ModelAttribute("Prestamo") Prestamo Prestamo) {
		Date fecha = new Date();
		Prestamo.setInicio(fecha);
		List<estadoCopia> listEstadoCopia = esCService.listEstadoCopia();
		Prestamo.getCopia().setEstadoCopia(listEstadoCopia.get(0));
		PService.savePrestamo(Prestamo);
		return "redirect:/";
	}
	

	@PostMapping("/saveDevolver")
	public String saveDevolver(@ModelAttribute("Prestamo") Long id) {
		Date fecha = new Date();
		List<estadoCopia> listEstadoCopia = esCService.listEstadoCopia();
		Prestamo prestamo = PService.getPrestamoById(id);
			prestamo.setFin(fecha);
			prestamo.getCopia().setEstadoCopia(listEstadoCopia.get(2));
			PService.savePrestamo(prestamo);
		return "redirect:/";
	}

	@GetMapping("/update/{id}")
	public String showFormForUpdate(@PathVariable(value="id") long id, Model model) {
		List<Autor> listAutores = AService.listarAutor();
		Libro libro=LService.getLibrobyId(id);
		model.addAttribute("listAutores", listAutores);
		model.addAttribute("Libro", libro);
		return "update_Libro";
	}
	
	
	@GetMapping("/delete/{id}")
	public String deleteLibro(@PathVariable(value="id") long id) {
		this.LService.deleteLibrobyId(id);
		return "redirect:/";
	}

}
