package com.indra.Biblioteca.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.indra.Biblioteca.model.Prestamo;

public interface PrestamoRepository extends JpaRepository<Prestamo, Long>{
	
	@Query(value="select p.* from prestamo p\r\n"
			+ "join copia c on p.copia = c.id\r\n"
			+ "where c.libro = :libro AND c.estado_copia = 1;",nativeQuery = true)
	List<Prestamo> listPrestamobyCopia(@Param("libro")long id);
	
	@Query(value="select * from prestamo where id = :id",nativeQuery = true)
	Prestamo PrestamobyId(@Param("id")long id);
}
