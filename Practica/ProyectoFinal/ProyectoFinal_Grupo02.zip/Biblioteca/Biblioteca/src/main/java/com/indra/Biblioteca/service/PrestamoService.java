package com.indra.Biblioteca.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.query.Param;

import com.indra.Biblioteca.model.Prestamo;



public interface PrestamoService {
	List<Prestamo> listarPrestamo();

	void savePrestamo(Prestamo Prestamo);
	List<Prestamo> listPrestamobyCopia(long id);

	Prestamo getPrestamoById(Long id);
}
