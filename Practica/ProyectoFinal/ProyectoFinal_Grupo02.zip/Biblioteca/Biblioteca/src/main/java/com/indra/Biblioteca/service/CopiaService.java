package com.indra.Biblioteca.service;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.indra.Biblioteca.model.Copia;

public interface CopiaService {
	List<Copia> listarCopia();
	List<Copia> listCopiabyLibro(long id);
	void saveCopia(Copia Copia);
	List<Copia> listCopiabyLibroByEstado(long id);
	List<Copia> listarCopiaPrestado();
	List<Copia> listCopiabyLibroByEstadoPrestado(long id);
}
