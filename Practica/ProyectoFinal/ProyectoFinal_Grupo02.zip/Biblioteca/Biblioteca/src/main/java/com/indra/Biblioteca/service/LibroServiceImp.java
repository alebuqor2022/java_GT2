package com.indra.Biblioteca.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.Biblioteca.model.Autor;
import com.indra.Biblioteca.model.Libro;
import com.indra.Biblioteca.repository.LibroRepository;


@Service
public class LibroServiceImp implements LibroService{

	@Autowired 
	private LibroRepository repositorio;
	
	
	@Override
	public List<Libro> listar() {
		return this.repositorio.findAll();
	}
	
	@Override
	public void saveLibro(Libro Libro) {
		this.repositorio.save(Libro);
	}

	@Override
	public void deleteLibrobyId(long id) {
		this.repositorio.deleteById(id);
	}
	
	@Override
	public Libro getLibrobyId(long id) {
		
		Optional<Libro> optionalLibro=this.repositorio.findById(id);
		Libro libro=null;
		if(optionalLibro.isPresent()) {
			libro=optionalLibro.get();
		}else {
			throw new RuntimeException("el Libro no se encuentra nro: " + id);
		}
		
		return libro;
	}

	@Override
	public List<Libro> findLibrobyAutor(String id) {
		return this.repositorio.findLibrobyAutor(id);
	}

}
