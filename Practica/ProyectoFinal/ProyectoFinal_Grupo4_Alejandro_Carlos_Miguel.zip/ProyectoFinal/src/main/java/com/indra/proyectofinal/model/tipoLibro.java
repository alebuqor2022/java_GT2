package com.indra.proyectofinal.model;

public enum tipoLibro {
	//NOVELA, TEATRO, POESIA, ENSAYO
	novela, teatro, poesia, ensayo
}
