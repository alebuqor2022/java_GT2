package com.indra.proyectofinal.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.proyectofinal.model.Libro;
import com.indra.proyectofinal.repository.LibroRepository;

@Service
public class LibroServiceImp implements LibroService {
	
	@Autowired 
	private LibroRepository libroRepository;
	
	@Override
	public List<Libro> getAllLibros() {
		return this.libroRepository.findAll();
	}
	
	@Override
	public void saveLibro(Libro libro) {
		this.libroRepository.save(libro);
	}

	@Override
	public Libro getLibroById(long id) {
		Optional<Libro> optionalLibro=this.libroRepository.findById(id);
		Libro libro = null;
		if(optionalLibro.isPresent()) {
			libro = optionalLibro.get();
		}else {
			throw new RuntimeException("El Libro con id "+ id +" no se encuentra");
		}
		return libro;
	}

	@Override
	public void deleteLibroById(long id) {
		this.libroRepository.deleteById(id);
		
	}
}