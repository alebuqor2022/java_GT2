package com.indra.proyectofinal.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="libros")
public class Libro {
	@SuppressWarnings("unused")
	private static final long serialVersionUID= -1L;
	
	@Id
	@Column
	private long idLibro;
	
	@Column
	private String titulo;
	
	@Column
	@Enumerated(value = EnumType.STRING)
	private tipoLibro tipo;
	
	@Column
	private String editorial;
	
	@Column
	private int anyo;
	
	@Column
	private String nombreAutor;
	
	@Column
	private String nacionalidadAutor;
	
	@Column
	//@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date fechaNacimiento;

	public Libro() {

	}
	
	public Libro(long id, String titulo, tipoLibro tipo, String editorial, int anyo, String nombreAutor,
			String nacionalidadAutor, Date fechaNacimiento) {
		this.idLibro = id;
		this.titulo = titulo;
		this.tipo = tipo;
		this.editorial = editorial;
		this.anyo = anyo;
		this.nombreAutor = nombreAutor;
		this.nacionalidadAutor = nacionalidadAutor;
		this.fechaNacimiento = fechaNacimiento;
	}

	public long getId() {
		return idLibro;
	}

	public void setId(long id) {
		this.idLibro = id;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public tipoLibro getTipo() {
		return tipo;
	}

	public void setTipo(tipoLibro tipo) {
		this.tipo = tipo;
	}

	public String getEditorial() {
		return editorial;
	}

	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}

	public int getAnyo() {
		return anyo;
	}

	public void setAnyo(int anyo) {
		this.anyo = anyo;
	}

	public String getNombreAutor() {
		return nombreAutor;
	}

	public void setNombreAutor(String nombreAutor) {
		this.nombreAutor = nombreAutor;
	}

	public String getNacionalidadAutor() {
		return nacionalidadAutor;
	}

	public void setNacionalidadAutor(String nacionalidadAutor) {
		this.nacionalidadAutor = nacionalidadAutor;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	
}
