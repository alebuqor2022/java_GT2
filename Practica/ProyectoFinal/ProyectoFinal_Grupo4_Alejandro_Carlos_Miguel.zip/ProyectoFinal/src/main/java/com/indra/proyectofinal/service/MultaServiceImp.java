package com.indra.proyectofinal.service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.proyectofinal.model.Multa;

import com.indra.proyectofinal.repository.MultaRepository;

@Service
public class MultaServiceImp implements MultaService{
	
	@Autowired 
	private MultaRepository multaRepository;
	
	@Override
	public List<Multa> getAllMultas() {
		comprobarMultas();
		return this.multaRepository.findAll();
	}
	
	@Override
	public void saveMulta(Multa multa) {
		this.multaRepository.save(multa);
	}

	@Override
	public Multa getMultaById(long id) {
		comprobarMultas();
		Optional<Multa> optionalMulta=this.multaRepository.findById(id);
		Multa multa = null;
		if(optionalMulta.isPresent()) {
			multa = optionalMulta.get();
		}else {
			throw new RuntimeException("La multa con id "+ id +" no se encuentra");
		}
		return multa;
	}

	@Override
	public void deleteMultaById(long id) {
		this.multaRepository.deleteById(id);
		
	}
	
	/*
	 * Recibe un id de lector y devuelve la multa que tuviera asociada.
	 */
	@Override
	public Multa getMultaByLectorId(long id) {
		comprobarMultas();
		List<Multa> listaMulta=this.multaRepository.findAll();
		Multa multa = null;
		for (Multa m: listaMulta) {
			if (m.getLector().getnSocio() == id) {
				multa = m;
			}
		}	
		return multa;
	}
	
	/*
	 * Este m�todo se le llama cada vez que se consultan las multas para que compruebe si se ha cumplido el plazo.
	 * En caso afirmativo, borra la multa antes de devolver el resultado de un getAll, getById...
	 */
	@Override
	public void comprobarMultas() {
		List <Multa> listaMultas = this.multaRepository.findAll();
		LocalDate date = LocalDate.now();
		ZoneId defaultZoneId = ZoneId.systemDefault();
		Date actual = Date.from(date.atStartOfDay(defaultZoneId).toInstant());
		for (Multa m: listaMultas) {
			if (m.getFechaFin().getTime() < actual.getTime()) {
				deleteMultaById(m.getIdMulta());
			}
		}
	}
}