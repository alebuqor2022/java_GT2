package com.indra.proyectofinal.service;

import java.util.List;

import com.indra.proyectofinal.model.Prestamo;

public interface PrestamoService {
	
	List<Prestamo> getAllPrestamos();
	List<Prestamo> getAllPrestamosByLector(long id);
	void savePrestamo(Prestamo prestamo);
	Prestamo getPrestamoById(long id);
	void deletePrestamoById(long id);

}