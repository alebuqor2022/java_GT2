package com.indra.proyectofinal.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.proyectofinal.model.Lector;
import com.indra.proyectofinal.repository.LectorRepository;

@Service
public class LectorServiceImp implements LectorService{
	
	@Autowired 
	private LectorRepository lectorRepository;
	
	
	@Override
	public List<Lector> getAllLectores() {
		return this.lectorRepository.findAll();
	}
	

	@Override
	public void saveLector(Lector lector) {
		this.lectorRepository.save(lector);
	}

	@Override
	public Lector getLectorById(long id) {
		Optional<Lector> optionalLector=this.lectorRepository.findById(id);
		Lector lector = null;
		if(optionalLector.isPresent()) {
			lector = optionalLector.get();
		}else {
			throw new RuntimeException("El Lector con id "+ id +" no se encuentra");
		}
		return lector;
	}

	@Override
	public void deleteLectorById(long id) {
		this.lectorRepository.deleteById(id);
		
	}

}