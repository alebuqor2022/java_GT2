package com.indra.proyectofinal.service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.proyectofinal.model.Copia;
import com.indra.proyectofinal.model.Multa;
import com.indra.proyectofinal.model.Prestamo;
import com.indra.proyectofinal.model.estadoCopia;
import com.indra.proyectofinal.repository.CopiaRepository;
import com.indra.proyectofinal.repository.PrestamoRepository;

@Service
public class CopiaServiceImp implements CopiaService{
	
	@Autowired 
	private CopiaRepository copiaRepository;
	
	@Autowired 
	private PrestamoRepository prestamoRepository;
	
	@Override
	public List<Copia> getAllCopias() {
		comprobarPrestamos();
		return this.copiaRepository.findAll();
	}

	@Override
	public List<Copia> getAllCopiasDisponibles() {
		comprobarPrestamos();
		List<Copia> listaTotal = this.copiaRepository.findAll();
		List<Copia> resultado = new ArrayList<Copia>();
		for (Copia c: listaTotal) {
			if(c.getEstadoCopia().equals(estadoCopia.biblioteca)) {
				resultado.add(c);
			}
		}
		return resultado;
	}
	/*
	 * Este m�todo se utiliza para actualizar el estado de una copia de "biblioteca" a "prestado" y viceversa.
	 * Recibe el id de la copia a actualizar y su nuevo estado.
	 */
	@Override
	public void actualizarCopiaById(long id, estadoCopia estado) { 
		Copia actualizar = getCopiaById(id);
		actualizar.setEstadoCopia(estado);
		this.copiaRepository.save(actualizar);
	}
	
	
	@Override
	public void saveCopia(Copia copia) {
		this.copiaRepository.save(copia);
		
	}

	@Override
	public Copia getCopiaById(long id) {
		Optional<Copia> optionalCopia=this.copiaRepository.findById(id);
		Copia copia = null;
		if(optionalCopia.isPresent()) {
			copia = optionalCopia.get();
		}else {
			throw new RuntimeException("La copia con id "+ id +" no se encuentra");
		}
		return copia;
	}
	

	@Override
	public void deleteCopiaById(long id) {
		this.copiaRepository.deleteById(id);
	}
	
	/*
	 * Al listar las copias, comprueba si alguna copia est� retrasada y actualiza su estado.
	 */
	@Override
	public void comprobarPrestamos() {
		List <Prestamo> listaPrestamos = this.prestamoRepository.findAll();
		LocalDate date = LocalDate.now();
		ZoneId defaultZoneId = ZoneId.systemDefault();
		Date actual = Date.from(date.atStartOfDay(defaultZoneId).toInstant());
		for (Prestamo p: listaPrestamos) {
			if (p.getFechaFin().getTime() < actual.getTime()) {
				actualizarCopiaById(p.getCopia().getIdCopia(), estadoCopia.retraso);
			}
		}
	}
}