package com.indra.proyectofinal.service;

import java.util.List;

import com.indra.proyectofinal.model.Multa;

public interface MultaService {
	
	List<Multa> getAllMultas();
	void saveMulta(Multa multa);
	Multa getMultaById(long id);
	Multa getMultaByLectorId(long id);
	void deleteMultaById(long id);
	void comprobarMultas();

}
