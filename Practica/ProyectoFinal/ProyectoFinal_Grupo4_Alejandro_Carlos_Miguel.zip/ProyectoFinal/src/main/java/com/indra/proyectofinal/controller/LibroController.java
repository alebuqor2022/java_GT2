package com.indra.proyectofinal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.indra.proyectofinal.model.Libro;
import com.indra.proyectofinal.service.LibroService;

@Controller
public class LibroController {
	
	@Autowired
	private LibroService libroService;
	
	
	@GetMapping("/libro")
	public String viewHomePage(Model model) {
		List<Libro> listLibros = this.libroService.getAllLibros();
		model.addAttribute("listLibros", listLibros);
		return "libro";
	}
	
	@PostMapping("/libro/save")
	public String saveLibro(@ModelAttribute("book") Libro libro) {
		this.libroService.saveLibro(libro);
	return "redirect:/libro";
	}
	
	@GetMapping("/libro/delete/{id}")
	public String deleteLibro(@PathVariable(value="id") long id) {
		this.libroService.deleteLibroById(id);
		return "redirect:/libro";
	}
	
	@GetMapping("/libro/update/{id}")
	public String showFormForUpdate(@PathVariable(value="id") long id, Model model) {
		Libro libro=this.libroService.getLibroById(id);
		model.addAttribute("book", libro);
		return "update_book";
	}
	
	@GetMapping("/libro/add")
	public String showNewLibroForm(Model model) {
		Libro libro = new Libro();
		model.addAttribute("book", libro);
		return "new_book";
	}
}