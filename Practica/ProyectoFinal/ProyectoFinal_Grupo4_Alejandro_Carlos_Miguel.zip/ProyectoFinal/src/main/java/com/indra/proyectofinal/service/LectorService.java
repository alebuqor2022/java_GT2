package com.indra.proyectofinal.service;

import java.util.List;

import com.indra.proyectofinal.model.Lector;


public interface LectorService {
	
	List<Lector> getAllLectores();
	void saveLector(Lector lector);
	Lector getLectorById(long id);
	void deleteLectorById(long id);
	
}