package com.indra.proyectofinal.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="multas")
public class Multa {
	@SuppressWarnings("unused")
	private static final long serialVersionUID= -1L;
	
	@Id
    @Column
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	private long idMulta;
	
	@Column
	private Date fechaInicio;
	
	@Column
	private Date fechaFin;
	
	@OneToOne
	@JoinColumn(name="fk_nSocio", unique = true)
	private Lector lector;
	
	public Multa() {

	}
	
	public Multa(long idMulta, Date fechaInicio, Date fechaFin, Lector lector) {
		this.idMulta = idMulta;
		this.fechaInicio = fechaInicio;
		this.fechaFin = fechaFin;
		this.lector = lector;
	}

	public long getIdMulta() {
		return idMulta;
	}

	public void setIdMulta(long idMulta) {
		this.idMulta = idMulta;
	}

	public Date getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public Date getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}

	public Lector getLector() {
		return lector;
	}

	public void setLector(Lector lector) {
		this.lector = lector;
	}
	
}