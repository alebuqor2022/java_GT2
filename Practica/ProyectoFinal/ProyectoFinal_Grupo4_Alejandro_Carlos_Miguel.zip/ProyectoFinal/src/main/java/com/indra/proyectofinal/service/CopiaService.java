package com.indra.proyectofinal.service;

import java.util.List;

import com.indra.proyectofinal.model.Copia;
import com.indra.proyectofinal.model.estadoCopia;

public interface CopiaService {
	
	List<Copia> getAllCopias();
	List<Copia> getAllCopiasDisponibles();
	void saveCopia(Copia copia);
	Copia getCopiaById(long id);
	void deleteCopiaById(long id);
	void actualizarCopiaById(long id, estadoCopia estado);
	void comprobarPrestamos();

}