package com.indra.proyectofinal.controller;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.indra.proyectofinal.model.Multa;
import com.indra.proyectofinal.model.Prestamo;
import com.indra.proyectofinal.model.estadoCopia;
import com.indra.proyectofinal.service.CopiaService;
import com.indra.proyectofinal.service.MultaService;
import com.indra.proyectofinal.service.PrestamoService;

@Controller
public class PrestamoController {
	
	@Autowired
	private PrestamoService prestamoService;
	
	@Autowired
	private CopiaService copiaService;
	
	@Autowired
	private MultaService multaService;

	
	@GetMapping("/prestamo")
	public String viewHomePage(Model model) {
		List<Prestamo> listPrestamos = this.prestamoService.getAllPrestamos();
		model.addAttribute("listPrestamos", listPrestamos);
		return "prestamo";
	}
	
	@PostMapping("/prestamo/save")
	public String savePrestamo(@ModelAttribute("borrow") Prestamo prestamo) {
		this.prestamoService.savePrestamo(prestamo);
	return "redirect:/prestamo";
	}
	
	/*
	 * Al borrar un pr�stamo, actualiza autom�ticamente el estado de la copia, pas�ndolo a "biblioteca".
	 * Adem�s, comprueba si la devoluci�n ha sido en plazo para asignar una multa si corresponde.
	 */
	@GetMapping("/prestamo/delete/{id}")
	public String deletePrestamo(@PathVariable(value="id") long id) {
		Prestamo p = this.prestamoService.getPrestamoById(id);
		long idCopia = p.getCopia().getIdCopia();
		this.copiaService.actualizarCopiaById(idCopia, estadoCopia.biblioteca);
		this.prestamoService.deletePrestamoById(id);
		
		LocalDate date = LocalDate.now();
		ZoneId defaultZoneId = ZoneId.systemDefault();
		Date actual = Date.from(date.atStartOfDay(defaultZoneId).toInstant());
		long tiempoTranscurrido= actual.getTime() - p.getFechaFin().getTime();
		tiempoTranscurrido = tiempoTranscurrido/ 86400000;
		if (tiempoTranscurrido > 0) {
			Multa m = new Multa();
			m.setFechaInicio(actual);
			LocalDate tiempoMulta = date.plusDays(tiempoTranscurrido * 2);
			Date finMulta = Date.from(tiempoMulta.atStartOfDay(defaultZoneId).toInstant());
			m.setFechaFin(finMulta);
			m.setLector(p.getLector());
			this.multaService.saveMulta(m);
		}
		return "redirect:/lector";
	}
	
	@GetMapping("/prestamo/update/{id}")
	public String showFormForUpdate(@PathVariable(value="id") long id, Model model) {
		Prestamo prestamo=this.prestamoService.getPrestamoById(id);
		model.addAttribute("borrow", prestamo);
		return "update_borrow";
	}
	
	@GetMapping("/prestamo/add")
	public String showNewPrestamoForm(Model model) {
		Prestamo prestamo= new Prestamo();
		model.addAttribute("borrow", prestamo);
		return "new_borrow";
	}
}