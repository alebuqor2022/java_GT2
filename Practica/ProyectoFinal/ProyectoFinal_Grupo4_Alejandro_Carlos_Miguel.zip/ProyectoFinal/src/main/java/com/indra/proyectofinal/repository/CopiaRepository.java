package com.indra.proyectofinal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.indra.proyectofinal.model.Copia;


public interface CopiaRepository extends JpaRepository<Copia, Long>{
	
	
}
