package com.indra.proyectofinal.service;

import java.util.List;

import com.indra.proyectofinal.model.Libro;

public interface LibroService {
	
	List<Libro> getAllLibros();
	void saveLibro(Libro libro);
	Libro getLibroById(long id);
	void deleteLibroById(long id);
	
	
}
