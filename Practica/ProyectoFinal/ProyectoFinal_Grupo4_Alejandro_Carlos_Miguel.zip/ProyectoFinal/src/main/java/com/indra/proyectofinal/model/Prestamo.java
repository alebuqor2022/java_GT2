package com.indra.proyectofinal.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="prestamos")
public class Prestamo {
	@SuppressWarnings("unused")
	private static final long serialVersionUID= -1L;
	
	@Id
	@Column(name="id_prestamo")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long idPrestamo;
	
	
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="pk_fk_copia")
	private Copia copia;
	
    @OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="fk_socio")
	private Lector lector;
	
	@Column
	private Date fechaInicio;
	
	@Column
	private Date fechaFin;
	
	public Prestamo() {

	}

	public Prestamo(long id, Copia copia, Lector lector, Date fechaInicio, Date fechaFin) {
		this.idPrestamo = id;
		this.copia = copia;
		this.lector = lector;
		this.fechaInicio = fechaInicio;
		this.fechaFin = fechaFin;
	}
	
	public long getIdPrestamo() {
		return idPrestamo;
	}

	public void setIdPrestamo(long idPrestamo) {
		this.idPrestamo = idPrestamo;
	}

	public Copia getCopia() {
		return copia;
	}

	public void setCopia(Copia copia) {
		this.copia = copia;
	}

	public Lector getLector() {
		return lector;
	}

	public void setLector(Lector lector) {
		this.lector = lector;
	}

	public Date getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public Date getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}
}