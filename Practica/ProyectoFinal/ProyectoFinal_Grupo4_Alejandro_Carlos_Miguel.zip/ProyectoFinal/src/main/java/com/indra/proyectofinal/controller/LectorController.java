package com.indra.proyectofinal.controller;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.indra.proyectofinal.model.Copia;
import com.indra.proyectofinal.model.Lector;
import com.indra.proyectofinal.model.Multa;
import com.indra.proyectofinal.model.Prestamo;
import com.indra.proyectofinal.model.estadoCopia;
import com.indra.proyectofinal.service.CopiaService;
import com.indra.proyectofinal.service.LectorService;
import com.indra.proyectofinal.service.MultaService;
import com.indra.proyectofinal.service.PrestamoService;

@Controller
public class LectorController {
	
	@Autowired
	private LectorService lectorService;
	
	@Autowired
	private PrestamoService prestamoService;
	
	@Autowired
	private CopiaService copiaService;
	
	@Autowired
	private MultaService multaService;
	
	@GetMapping("/lector")
	public String viewHomePage(Model model) {
		List<Lector> listLectores = this.lectorService.getAllLectores();
		model.addAttribute("listLectores", listLectores);	
		return "lector";
	}
	
	
	@PostMapping("/lector/save")
	public String saveLector(@ModelAttribute("reader") Lector lector) {
		this.lectorService.saveLector(lector);
	return "redirect:/lector";
	}
	
	@GetMapping("/lector/delete/{id}")
	public String deleteLector(@PathVariable(value="id") long id) {
		this.lectorService.deleteLectorById(id);
		return "redirect:/lector";
	}
	
	@GetMapping("/lector/update/{id}")
	public String showFormForUpdate(@PathVariable(value="id") long id, Model model) {
		Lector lector=this.lectorService.getLectorById(id);
		model.addAttribute("reader", lector);
		return "update_reader";
	}
	
	@GetMapping("/lector/add")
	public String showNewLectorForm(Model model) {
		Lector lector = new Lector();
		model.addAttribute("reader", lector);
		return "new_reader";
	}
	
	/*
	 * Obtiene todos los pr�stamos que tiene el lector con el id indicado.
	 */
	@GetMapping("/lector/prestamo_lector/{id}")
	public String showPrestamosForm(@PathVariable(value="id") long id,Model model) {
		Lector lector=this.lectorService.getLectorById(id);
		List<Prestamo> prestamo = this.prestamoService.getAllPrestamosByLector(id);
		model.addAttribute("reader", lector);
		model.addAttribute("listPrestamos", prestamo);
		return "/prestamo_lector";
	}
	/*
	 * Este m�todo muestra el total de copias disponibles (con estado = "biblioteca"), arrastrando el id de un lector
	 * para solicitar el pr�stamo de la copia elegida.
	 */
	@GetMapping("/lector/prestamo_copia/{id}")
	public String showCopiasForm(@PathVariable(value="id") long id,Model model) {
		Lector lector=this.lectorService.getLectorById(id);
		List<Copia> copias = this.copiaService.getAllCopiasDisponibles();
		model.addAttribute("reader", lector);
		model.addAttribute("listCopiasPrestamo", copias);
		return "/prestamo_copia";
	}
	/*
	 * Con la informaci�n mostrada en el m�todo showCopiasForm, desde este m�todo se solicita el pr�stamo 
	 * de la copia elegida.
	 * Se comprueba que el lector no tenga ya tres pr�stamos activos.
	 * Luego se comprueba si el lector tiene alguna multa pendiente.
	 * En caso de que se cumplan las condiciones, se realiza el pr�stamo y se actualiza el estado de la copia.
	 * En caso contrario, deriva a una p�gina de alerta.
	 */
	@GetMapping("/lector/prestamo_copia/{id}/prestar/{idCopia}")
		public String savePrestamo(@PathVariable(value="id") long idLector,
				@PathVariable(value="idCopia") long idCopia,
				Model model) {
		model.addAttribute("id", idLector);
		List <Prestamo> comprobarPrestamos = this.prestamoService.getAllPrestamos();
		int contador = 0;
		for(Prestamo p: comprobarPrestamos) {
			if (p.getLector().getnSocio() == idLector) {
				contador++;
			}
		}
		Multa m = this.multaService.getMultaByLectorId(idLector);
		
		if (contador < 3 && (m == null)) {
			this.copiaService.actualizarCopiaById(idCopia, estadoCopia.prestado);
			Copia c = this.copiaService.getCopiaById(idCopia);
			Lector l = this.lectorService.getLectorById(idLector);
			
			LocalDate date = LocalDate.now();
			LocalDate date2 = date.plusDays(30);
			ZoneId defaultZoneId = ZoneId.systemDefault();
			Date actual = Date.from(date.atStartOfDay(defaultZoneId).toInstant());
			Date fin = Date.from(date2.atStartOfDay(defaultZoneId).toInstant());
			
			Prestamo p = new Prestamo();
			p.setCopia(c);
			p.setLector(l);
			p.setFechaInicio(actual);
			p.setFechaFin(fin);
			this.prestamoService.savePrestamo(p);
			return "redirect:/lector";
		}else {
			return "error_prestamo";
		}
	}	
}