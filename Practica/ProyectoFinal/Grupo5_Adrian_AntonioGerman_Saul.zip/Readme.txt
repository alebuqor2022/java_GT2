Es necesario usar una aplicaccion de gestion de bbdd,
despues de estar intalada ejecutamos el biblioteca.sql,
e importamos el proyecto.war en eclipse.