-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema BIBLIOTECA
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema BIBLIOTECA
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `BIBLIOTECA` DEFAULT CHARACTER SET utf8 COLLATE utf8_esperanto_ci ;
-- -----------------------------------------------------
-- Schema biblioteca
-- -----------------------------------------------------
USE `BIBLIOTECA` ;

-- -----------------------------------------------------
-- Table `BIBLIOTECA`.`Libro`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `BIBLIOTECA`.`Libro` (
  `idLibro` int COLLATE utf8mb3_esperanto_ci NOT NULL auto_increment,
  `titulo` varchar(25) COLLATE utf8mb3_esperanto_ci NOT NULL,
  `tipo` varchar(45) COLLATE utf8mb3_esperanto_ci DEFAULT NULL,
  `editorial` varchar(45) COLLATE utf8mb3_esperanto_ci DEFAULT NULL,
  `anyo` int DEFAULT NULL,
  PRIMARY KEY (`idLibro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_esperanto_ci;



-- -----------------------------------------------------
-- Table `BIBLIOTECA`.`tipoLibro`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `BIBLIOTECA`.`tipoLibro` (
  `novela` VARCHAR(25) NULL,
  `teatro` VARCHAR(45) NULL,
  `poesia` VARCHAR(45) NULL,
  `ensayo` VARCHAR(45) NULL)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `BIBLIOTECA`.`Autor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `BIBLIOTECA`.`Autor` (
  `nombre` VARCHAR(45) NOT NULL,
  `nacionalidad` VARCHAR(45) NULL,
  `fechaNacimiento` DATE NULL,
  `Libro_titulo` VARCHAR(25) NOT NULL,
  PRIMARY KEY (`nombre`, `Libro_titulo`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `BIBLIOTECA`.`Copia`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `BIBLIOTECA`.`Copia` (
  `id` INT NOT NULL,
  `estado` VARCHAR(45) NULL,
  `Libro_titulo` VARCHAR(25) NOT NULL,
  PRIMARY KEY (`id`, `Libro_titulo`),
  INDEX `fk_Copia_Libro_idx` (`Libro_titulo` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `BIBLIOTECA`.`estadoCopia`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `BIBLIOTECA`.`estadoCopia` (
  `prestado` INT NULL,
  `retraso` VARCHAR(45) NULL,
  `biblioteca` VARCHAR(45) NULL,
  `reparacion` VARCHAR(45) NULL)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `BIBLIOTECA`.`Lector`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `BIBLIOTECA`.`Lector` (
  `nSocio` INT NOT NULL,
  `nombreLector` VARCHAR(45) NULL,
  `telefono` INT NULL,
  `direccion` VARCHAR(45) NULL,
  PRIMARY KEY (`nSocio`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `BIBLIOTECA`.`Multa`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `BIBLIOTECA`.`Multa` (
  `fechaInicio` DATE NULL,
  `fechaFin` DATE NULL,
  `Lector_nSocio` INT NOT NULL,
  PRIMARY KEY (`Lector_nSocio`),
  CONSTRAINT `fk_Multa_Lector1`
    FOREIGN KEY (`Lector_nSocio`)
    REFERENCES `BIBLIOTECA`.`Lector` (`nSocio`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `BIBLIOTECA`.`Prestamo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `BIBLIOTECA`.`Prestamo` (
  `inicio` DATE NULL,
  `fin` DATE NULL,
  `Copia_id` INT NOT NULL,
  `Copia_Libro_titulo` VARCHAR(25) NOT NULL,
  `Lector_nSocio` INT NOT NULL,
  INDEX `fk_Prestamo_Copia1_idx` (`Copia_id` ASC, `Copia_Libro_titulo` ASC) VISIBLE,
  INDEX `fk_Prestamo_Lector1_idx` (`Lector_nSocio` ASC) VISIBLE,
  CONSTRAINT `fk_Prestamo_Copia1`
    FOREIGN KEY (`Copia_id` , `Copia_Libro_titulo`)
    REFERENCES `BIBLIOTECA`.`Copia` (`id` , `Libro_titulo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Prestamo_Lector1`
    FOREIGN KEY (`Lector_nSocio`)
    REFERENCES `BIBLIOTECA`.`Lector` (`nSocio`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
