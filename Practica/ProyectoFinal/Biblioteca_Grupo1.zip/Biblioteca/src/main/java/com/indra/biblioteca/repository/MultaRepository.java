package com.indra.biblioteca.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.indra.biblioteca.model.Multa;



public interface MultaRepository extends JpaRepository<Multa, Long>{

}
