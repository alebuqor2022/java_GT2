package com.indra.biblioteca.model;

public enum TipoLibro {
	novela, teatro, poesia,ensayo;
}
