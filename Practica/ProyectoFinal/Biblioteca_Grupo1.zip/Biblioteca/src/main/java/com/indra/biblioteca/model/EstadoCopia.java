package com.indra.biblioteca.model;

public enum EstadoCopia {
	prestada, retraso, bibilioteca, reparacion;
}
