package com.indra.biblioteca.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.indra.biblioteca.model.Copia;



public interface CopiaRepository extends JpaRepository<Copia, Long>{
}
