Tener preinstalado MysqlWorkbench
Tener preinstalado Eclipse 
Dentro de Eclipse > Help > Eclipse Market Place > Buscas SpringTools 4
Nombre base de datos: indrafinal1