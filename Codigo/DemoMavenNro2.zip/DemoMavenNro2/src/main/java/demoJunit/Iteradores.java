package demoJunit;

public class Iteradores {

	public boolean usoFor(int[] a, int[] b) {
		// if(a.equals(b))
		
		if(a.length == b.length) {
			return true;
		} else {
			return false;
		}
		
		
	}
	
}
