package demoJunit;

public class Calculadora {

	public int sumar(int var1, int var2) {
		System.out.println("estoy sumando");
		return var1 + var2;
	}
	public int restar(int var1, int var2) {
		System.out.println("estoy restando");
		return var1 - var2;
	}
	
}
