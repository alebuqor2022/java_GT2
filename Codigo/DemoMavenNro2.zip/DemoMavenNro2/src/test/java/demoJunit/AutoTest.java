package demoJunit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class AutoTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("estoy en el BeforeClass");
	}	

	
	@Before
	public void setUp() throws Exception {
		System.out.println("estoy en el Before");
	}


	@Test
	public void testImprimirInfo() {
		System.out.println("estoy en el Test de ImprimirInfo");
		Auto miAuto=new Auto("Ford","gris",2.0);
		String actual=miAuto.getColor();
		String expected=new String(actual);
		//expected="negro";
		assertEquals(expected, miAuto.getColor());
		
		//fail("Not yet implemented");
	}

	@Test
	public void testSubirPotencia() {
		System.out.println("estoy en el Test de SubirPotencia");
		Auto miAuto=new Auto("Ford","gris",2.0);
		double actual=miAuto.getMotor();
		miAuto.subirPotencia(1.1);
		
		double expected=miAuto.getMotor();
		assertTrue(potenciaMaxima()>expected);
		//fail("Not yet implemented");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("estoy en el After");
	}
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("estoy en el AfterClass");
	}
	double potenciaMaxima() {
		return 3.0;
	}
}
