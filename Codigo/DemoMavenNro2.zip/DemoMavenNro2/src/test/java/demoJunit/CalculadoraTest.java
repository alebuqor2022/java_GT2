package demoJunit;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

public class CalculadoraTest {
	static Calculadora calculo;
	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("estoy en el BeforeClass");
		calculo=new Calculadora();
	}	
	
	@Test
	public void testSumar() {
		int suma=calculo.sumar(2, 5);
		// prueba feliz :-)
		int rpta1=7;
		System.out.println("@Test sumar(): " + suma + " = " + rpta1);
		assertEquals(suma, rpta1);
	}

	@Test
	public void testRestar() {
		int resta=calculo.restar(2, 5);
		// prueba feliz
		int rpta1=-3;
		System.out.println("@Test restar(): " + resta + " = " + rpta1);
		assertEquals(resta, rpta1);
		// prueba infeliz
		int rpta2=-3;
		System.out.println("@Test restar(): " + resta + " = " + rpta2);
		assertEquals(resta, rpta2);
		
	}

}
