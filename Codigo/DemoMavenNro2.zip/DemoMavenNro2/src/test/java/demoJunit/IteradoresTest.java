package demoJunit;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

public class IteradoresTest {
	static Iteradores i;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Estoy en el BeforeClass");
		i=new Iteradores();
	}

	@Test
	public void testUsoFor() {
		int[] a= new int[10];
		int b[]= new int[2];
		boolean rpta= i.usoFor(a, b);
		assertTrue(rpta);
		
	}

}
