package com.indra.abmPersona;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbmPersonaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbmPersonaApplication.class, args);
	}

}
