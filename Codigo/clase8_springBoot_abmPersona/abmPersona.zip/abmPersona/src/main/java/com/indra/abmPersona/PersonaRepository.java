package com.indra.abmPersona;

import java.util.List;

import org.springframework.data.repository.Repository;

public interface PersonaRepository extends Repository<Persona, Integer>{
// esta interface dialoga hacia el motor de MySQL
// CRUD ...ABM .... create, read, update, delete y consulta
	
List<Persona> findAll();
Persona findById(int id);
Persona save(Persona p);
void delete(Persona p);
	
	
}
