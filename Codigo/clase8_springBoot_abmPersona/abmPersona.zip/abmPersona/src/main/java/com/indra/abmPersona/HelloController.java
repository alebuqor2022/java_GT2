package com.indra.abmPersona;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

	// la "/" es el HOME de mi aplicacion web
	@GetMapping("/") // interactua con http://localhost:8080/
	public String index() {
		return "Saludos desde Spring Boot!!!!";
	}
	
}

// @RestController = @Controller (es un Bean) + @ResponseBody
// Annotations que son reconocidas como "Beans" por Spring
// @Component -> es como los POJOS 
// @Repository -> trabaja en la capa de acceso a datos hacia la BD
// (@JPARepository, @CRUDRepository)
// @Controller -> tipico de la capa de MVC
// @Service -> trabaja en la capa de servicios que consumen un acceso a datos






