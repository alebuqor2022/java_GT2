package com.indra.abmPersona;

import java.util.List;

public interface PersonaService {
// dialoga hace el frontEnd
	
	List<Persona> listar();
	Persona listarId(int id);
	Persona add(Persona p);
	Persona edit(Persona p);
	void delete(int id);
}
