package clase2;

public class TestPersona {

	public static void main(String[] args) {
		// estoy invocando el metodo constructor vacio
		Persona p=new Persona();
		// se pueden invocar si la visibilidad es package o public
//		p.nombre="Ale";
//		p.apellido="Buqu";
//		p.edad=35;
//		p.domicilio="Campana, Buenos Aires";
//		p.email="ale@gmail";
		
		// se invoca a traves de los SETTERS
		Mascota mia=new Mascota();
		
		p.setNombre("Ale");
		p.setApellido("Buqu");
		p.setDomicilio("Campana, Buenos Aires");
		p.setEdad(35);
		p.setEmail("ale@gmail");
		mia.setTipo("perro");
		mia.setNombre("Sultan");
		
		p.mostrarDatos();
		
		Persona p1=new Persona("Juan", "Garcia", mia);
		p1.mostrarDatos();

	}

}
