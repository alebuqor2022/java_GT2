package clase2;

public class Persona {
	// es un POJO = plain old java object => atributos con visibilidad private y GETTERS/SETTERS
	// caracteristicas, propiedades, campos, ATRIBUTOS
private String nombre;
private String apellido;
private int edad;
private String domicilio;
private String email;

private Mascota miMascota=new Mascota();

// OVERLOAD -sobrecarga- de metodos constructores
public Persona() {}

public Persona(String nombre, String apellido, Mascota mia) {
	this.nombre=nombre;
	this.apellido=apellido;
	this.miMascota=mia;
}

public Persona(String nombre, String apellido, int edad, String domicilio, String email,Mascota mia) {
	this.nombre=nombre;
	this.apellido=apellido;
	this.domicilio=domicilio;
	this.edad=edad;
	this.email=email;
	this.miMascota=mia;
}



void mostrarDatos() {
	System.out.println("me llamo " + nombre + " " + apellido);
	System.out.println("tengo " + edad + " a�os ");
	System.out.println("vivo en " + domicilio);
	System.out.println("mi mail es " + email);
	System.out.println("mi mascota se llama " + miMascota.getNombre());
}

public void setNombre(String nombre) {
	this.nombre=nombre;
}
public String getNombre() {
	return this.nombre;
}

public String getApellido() {
	return apellido;
}

public void setApellido(String apellido) {
	this.apellido = apellido;
}

public int getEdad() {
	return edad;
}

public void setEdad(int edad) {
	this.edad = edad;
}

public String getDomicilio() {
	return domicilio;
}

public void setDomicilio(String domicilio) {
	this.domicilio = domicilio;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}
}
