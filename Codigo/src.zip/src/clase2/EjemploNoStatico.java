package clase2;

public class EjemploNoStatico {
	String nombre;
	
	public static void main(String[] args) {
		EjemploNoStatico miObjeto=new EjemploNoStatico();
		miObjeto.imprimirNombre("Ale");
		miObjeto.nombre="Juan";
		System.out.println("chau " + miObjeto.nombre);
		
		EjemploNoStatico miObjeto2=new EjemploNoStatico();
		miObjeto2.imprimirNombre("Maria");
		miObjeto2.nombre="Jose";
		System.out.println("chau " + miObjeto2.nombre);

	}

	public void imprimirNombre(String valor) {
		System.out.println("hola " + valor);
	}

}
