package ejerciciosTP1;

public class Ejercicio2 {

	public static void main(String[] args) {
		

	}

}
