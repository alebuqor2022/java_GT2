package clase2;

public interface Ipagable {
void pagar(double cantidad);
}
