package clase2;

public abstract class Empleado { // no permite instancias directas de new Empleado
private String nombre;
private int edad;
protected int legajo;

public abstract void mostrarInfo(); // obligar a las hijas a colocar {} con codigo

public void mostrarInfo1() { // puedo hacer override o no
	System.out.println("hola");
}

public final void verAntiguedad() { // NO PERMITO OVERRIDING en las clases hijas
	System.out.println("mas de 10 a�os");
}

public String getNombre() {
	return nombre;
}
public void setNombre(String nombre) {
	this.nombre = nombre;
}
public int getEdad() {
	return edad;
}
public void setEdad(int edad) {
	this.edad = edad;
}
public int getLegajo() {
	return legajo;
}
public void setLegajo(int legajo) {
	this.legajo = legajo;
}

}
