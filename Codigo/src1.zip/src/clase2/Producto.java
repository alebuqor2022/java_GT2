package clase2;

public class Producto {

	String descripcion;
	double precio;
	static double iva;
	
	double calcularPrecioConIva() {
		return precio * iva;
	}

	public String getDescripcion() {
		return descripcion;
	}
	static double getIva() {
		return iva;
	}
}
