package clase2;

public class TestIF {

	public static void main(String[] args) {
		String valor="algo";
		int nro=8;
		
		if (valor != "algo") {
			System.out.println("no es algo");
		} else {
			System.out.println("es algo");
		}
		
		switch(nro) { // byte, short, char, boolean, int, String		
		case 1:
		case 2:
		case 3:		
			System.out.println("estoy en el grupo de 1 a 3");
			break;
		case 4: case 5: case 6:
			System.out.println("estoy en el grupo de 4 a 6");
			break;
		case 7-10: // no sirve, queda el resultado de la resta
			System.out.println("estoy en el grupo de 7 a 10");
			break;
		case 11,12,13,14,15: // a partir de la version 12 
			System.out.println("estoy en el grupo de 11 a 15");
			break;
		default:
			System.out.println("estoy fuera de grupo");
		}

	}

}
