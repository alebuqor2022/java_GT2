package clase1;

public class VariablesTest2 {

	public static void main(String[] args) {
		boolean unBoolean=true;
		char unChar='A';
		byte unByte=10;
		int unInt=10;
		long unLong=10L;
		float unFloat=10.0F;
		double unDouble=10.0D;
		String unString=new String("hola"); // seguimos el formato de instanciacion de objetos con el NEW
		String otroString="chau"; // usamos la abstraccion que nos permite String
		
		
		System.out.println("el valor de unBoolean es " + unBoolean);
		System.out.println("el valor de unChar es " + unChar);
		System.out.println("el valor de integer es " + unInt);
		System.out.println("el valor de unString es " + unString);
		System.out.println("el valor de otroString es " + otroString);
		
	}

}
