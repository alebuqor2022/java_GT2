package clase3;

public class Test {

	public static void main(String[] args) {
		Punto p1=new Punto(1,2);
		 Punto p2= new Punto(1,2);
		// Punto p2 = p1; // usando el mismo puntero de memoria
		System.out.println("p1: " + p1);
		System.out.println("p2: " + p2);
		
		// if(p1 == p2) { // no sirve para comparar objetos
		 if(p1.equals(p2)) {
			System.out.println("son iguales");
		} else {
			System.out.println("NO son iguales");
		}

		// equals : compara referencias
		// == : compara valores primitivos
	}

}

class Punto{
	public int x= 0;
	public int y= 0;
	
	public Punto(int param1, int param2) {
		this.x=param1;
		this.y=param2;
	}
	
	public boolean equals(Object obj) {
		Punto punto= (Punto) obj; // (Punto) --> casting 
		// comparamos los atributos 
		if( x == punto.x && y == punto.y) {
			return true;
		} else {
			return false;
		}
		
	}
	
}