package clase3;

public class Elipse extends Figura{

	double cedntro;
	double radioMayor;
	double radioMenor;
	
	public void dibujar() {
		System.out.println("dibujo una elipse");
	}
}
