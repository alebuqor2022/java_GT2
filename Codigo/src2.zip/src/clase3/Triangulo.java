package clase3;

public class Triangulo extends Figura{

}
