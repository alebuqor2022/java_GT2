package clase3;

public class Figura {

	public void mover(int i, int j) {
		System.out.println("la figura se mueve");
	}
	
	public double calcularArea(int a, int b) {
		return a * b;
	}
}
