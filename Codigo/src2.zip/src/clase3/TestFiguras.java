package clase3;

public class TestFiguras {

	public static void main(String[] args) {
		// arreglo o vector, definido []
		// los elementos pueden ser diferentes/heterogeneos
		Figura[] figuras= new Figura[4];
		
		figuras[0]=new Circulo();
		figuras[1]=new Elipse();
		figuras[2]=new Triangulo();
		figuras[3]=new Figura();
		
		definoFigura(figuras[1]);
	}
	
	public static void definoFigura(Figura f) {
		if (f instanceof Circulo) {
			System.out.println("recibi un circulo");
		} else if (f instanceof Elipse){
			System.out.println("recibi un elipse");
			
			((Elipse)f).dibujar(); // casteo figura a su hija
			
		}
		
		
	}

}
