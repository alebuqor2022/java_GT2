package clase2;

public class TestProducto {

	public static void main(String[] args) {
		Producto.iva=0.21;
		Producto p=new Producto();
		
		p.descripcion="lata de tomates";
		p.precio=28.5;
		
		Producto p1=new Producto();
		p1.descripcion="lata de atun";
		p1.precio=32;

		System.out.println(p.getDescripcion() + " el iva es: " + p.calcularPrecioConIva());
		System.out.println(p1.getDescripcion() + " el iva es: " + p1.calcularPrecioConIva());
	}

}
