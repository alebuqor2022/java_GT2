package clase2;

public class TestEmpleado {

	public static void main(String[] args) {
		// Empleado (superClass) ... Secretaria y Gerente (subclass)
		
		Secretaria s=new Secretaria();
		s.setNombre("Susanita");
		s.setNombreGerencia("Ventas");
		s.mostrarInfo();
		
		// no puedo instanciar directamente Empleado, dado que esta marcado con ABSTRACT
		// Empleado e= new Empleado();
		

	}

}
