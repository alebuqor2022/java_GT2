package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import model.Pais;
import utils.JpaUtils;

public class DaoPais {

	public static void create(Pais pais) {
		EntityManager em=JpaUtils.getEntityManagerFactory().createEntityManager();
		em.getTransaction().begin(); 
				
		try {
			em.persist(pais);
			em.getTransaction().commit();
		} catch (Exception e) {
			em.getTransaction().rollback();
			System.out.println("ocurrio un error al crear un pais");
			e.printStackTrace();
		}finally {
			em.close();
		}
		
	}
	
	public static void update(Pais pais) {
		EntityManager em=JpaUtils.getEntityManagerFactory().createEntityManager();
		EntityTransaction tx=em.getTransaction(); 
		tx.begin();
		
		try {
			em.merge(pais);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			System.out.println("ocurrio un error al actualizar un pais");
			e.printStackTrace();
		}finally {
			em.close();
			
		}

		
	}
	
		
	public static Pais find(Long id) {
		EntityManager em=JpaUtils.getEntityManagerFactory().createEntityManager();
		Pais p=null;
		
		try {
			p=em.find(Pais.class, id);
		} catch (Exception e) {
			System.out.println("no encontro al pais");
			e.printStackTrace();
		}finally {
			em.close();
		}
		
		return p;
		
	}
	

	public static void delete(Long id) {
		EntityManager em=JpaUtils.getEntityManagerFactory().createEntityManager();
		em.getTransaction().begin(); 
		
		try {
			Pais p=DaoPais.find(id);
			em.remove(p);
			em.getTransaction().commit();
		} catch (Exception e) {
			em.getTransaction().rollback();
			System.out.println("no borro al pais");
			e.printStackTrace();
		}finally {
			em.close();
		}
		
	}
}

