package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import model.Ciudad;
import utils.JpaUtils;

public class DaoCiudad {

	public static void create(Ciudad ciudad) {
		EntityManager em=JpaUtils.getEntityManagerFactory().createEntityManager();
		em.getTransaction().begin(); 
				
		try {
			em.persist(ciudad);
			em.getTransaction().commit();
		} catch (Exception e) {
			em.getTransaction().rollback();
			System.out.println("ocurrio un error al crear una ciudad");
			e.printStackTrace();
		}finally {
			em.close();
		}
		
	}
	
	public static void update(Ciudad ciudad) {
		EntityManager em=JpaUtils.getEntityManagerFactory().createEntityManager();
		EntityTransaction tx=em.getTransaction(); 
		tx.begin();
		
		try {
			em.merge(ciudad);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			System.out.println("ocurrio un error al actualizar una ciudad");
			e.printStackTrace();
		}finally {
			em.close();
		}
		
		
	}
	
	public static Ciudad find(Long id) {
		EntityManager em=JpaUtils.getEntityManagerFactory().createEntityManager();
		Ciudad p=null;
		
		try {
			p=em.find(Ciudad.class, id);
		} catch (Exception e) {
			System.out.println("no encontro a la ciudad");
			e.printStackTrace();
		}finally {
			em.close();
		}
		
		return p;
		
	}
	
	public static void delete(Long id) {
		EntityManager em=JpaUtils.getEntityManagerFactory().createEntityManager();
		em.getTransaction().begin(); 
		
		try {
			Ciudad p=DaoCiudad.find(id);
			em.remove(p);
			em.getTransaction().commit();
		} catch (Exception e) {
			em.getTransaction().rollback();
			System.out.println("no borro a la ciudad");
			e.printStackTrace();
		}finally {
			em.close();
		}
		
	}

}
