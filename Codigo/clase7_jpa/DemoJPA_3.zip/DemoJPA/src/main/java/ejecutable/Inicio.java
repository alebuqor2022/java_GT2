package ejecutable;

import java.util.Date;

import dao.DaoCiudad;
import dao.DaoEmpleado;
import dao.DaoPais;
import dao.DaoPersona;
import model.Ciudad;
import model.Empleado;
import model.Pais;
import model.Persona;

public class Inicio {

	public static void main(String[] args) {
	//	testPersona();
	//	testEmpleado();
		 crearPaises();
		 crearCiudades();

	}

	public static void testPersona() {
		Persona p=new Persona();
		p.setNombre("Adriana");
		p.setApellido("Garcia");
		p.setCedula("QWR897");
		
		Date d=new Date("2011/04/22"); // en la BD lo guarda como 2022-07-13
		p.setFechaNacimiento(d);
		DaoPersona.create(p);
		
		System.out.println("--- Persona en BD ----");
		Persona p1=DaoPersona.find(1L);
		System.out.println(p1.getNombre()+ ", " + p1.getApellido());
		
	}
	
	public static void testEmpleado() {
		Empleado e = new Empleado();
		e.setPassword("@!=%ABC!");
		Persona p=DaoPersona.find(1L);
		e.setPerson(p);		
		e.setUsuario("Alex");
		
		DaoEmpleado.create(e);
		System.out.println("--- Empleado en BD ----");
		Empleado e1=DaoEmpleado.find(1L);
		System.out.println(e1.getUsuario()+ ", " + e1.getPerson().getNombre());
	}

	public static void crearPaises() {
		Pais p=new Pais();
		p.setNombre("Espa�a");
		DaoPais.create(p);
		
		p=new Pais();
		p.setNombre("Argentina");
		DaoPais.create(p);
	}
	
	public static void crearCiudades() {
		// Espa�a
		Pais p=DaoPais.find(1L);
		Ciudad c= new Ciudad();
		c.setNombre("Madrid");
		c.setPais(p);
		DaoCiudad.create(c);
		
		c= new Ciudad();
		c.setNombre("Barcelona");
		c.setPais(p);
		DaoCiudad.create(c);
		
		c= new Ciudad();
		c.setNombre("Valencia");
		c.setPais(p);
		DaoCiudad.create(c);
		
		// Argentina
		Pais p=DaoPais.find(2L);
		Ciudad c= new Ciudad();
		c.setNombre("Buenos Aires");
		c.setPais(p);
		DaoCiudad.create(c);
		
		c= new Ciudad();
		c.setNombre("Rosario");
		c.setPais(p);
		DaoCiudad.create(c);
		
		c= new Ciudad();
		c.setNombre("Zarate");
		c.setPais(p);
		DaoCiudad.create(c);
	}
	
}
