package utils;

public class JpaUtils {
	// vamos a implementar la creacion de entidades con 
	// el EntityManager
	// trabajaria como el patron de dise�o llamado Singleton

}
