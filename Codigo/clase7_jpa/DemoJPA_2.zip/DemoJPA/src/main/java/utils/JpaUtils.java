package utils;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JpaUtils {
	// vamos a implementar la creacion de entidades con 
	// el EntityManager
	// trabajaria como el patron de dise�o llamado Singleton
	
	private static final EntityManagerFactory emf;
	
	static {
		
		try {
			emf=Persistence.createEntityManagerFactory("DemoJPA");
			// es el mismo nombre que tiene el archivo persistence.xml
		} catch (Throwable e) {
			System.out.println("La Factoria no inicio");
			e.printStackTrace();
			throw new ExceptionInInitializerError(e);
		} 
	
	}
	
	public static EntityManagerFactory getEntityManagerFactory() {
		return emf;
	}

}
