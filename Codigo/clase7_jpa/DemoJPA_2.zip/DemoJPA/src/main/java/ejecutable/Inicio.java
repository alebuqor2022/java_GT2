package ejecutable;

public class Inicio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
