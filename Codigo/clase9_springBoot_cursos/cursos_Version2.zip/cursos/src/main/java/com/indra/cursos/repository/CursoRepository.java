package com.indra.cursos.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.indra.cursos.model.Curso;

public interface CursoRepository extends JpaRepository<Curso, Long>{
// dialoga hacia la BD
}
