package com.indra.cursos.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.indra.cursos.model.Curso;

public interface CursoService {
	// dialoga hace el frontEnd
	
	List<Curso> getAllCursos();
	void saveCurso(Curso curso);
	Curso getCursoById(long id);
	void deleteCursoById(long id);
	
	Page<Curso> findPAginated(int pageNum, int pageSize, String sortField, String sortDirection );
	
}
