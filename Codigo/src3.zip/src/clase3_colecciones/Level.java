package clase3_colecciones;

public enum Level {
BAJO, MEDIO, ALTO
}
