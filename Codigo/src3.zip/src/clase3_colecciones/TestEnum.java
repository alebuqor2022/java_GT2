package clase3_colecciones;

public class TestEnum {

	public static void main(String[] args) {
		Level a=Level.BAJO;
		System.out.println(a);
		
		switch(a) {
		case BAJO:
			System.out.println("Es bajo");break;
		case MEDIO:
			System.out.println("Es medio");break;
		case ALTO:
			System.out.println("Es ALTO");break;
		default: 
			System.out.println("Es null");
		}

	}

}
