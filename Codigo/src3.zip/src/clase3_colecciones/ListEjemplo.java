package clase3_colecciones;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListEjemplo {

	public static void main(String[] args) {
		// permite elementos DUPLICADOS, y respeta el ORDEN de carga
		// lista ordenada con elementos duplicados
		ArrayList lista1=new ArrayList();
		List lista=new ArrayList();
		
		lista.add("uno");
		lista.add("segundo");
		lista.add("3ero");
		lista.add(4);
		lista.add("segundo");
		lista.add(2.5);
		lista.add(true);
		lista.add(4);
		
		System.out.println(lista);
		
		Iterator it=lista.iterator();
		
		while(it.hasNext()) {
			System.out.println(" " + it.next());
		}
		
	}

}
