package clase3;

public class Circulo extends Elipse{

	double radio;
}
