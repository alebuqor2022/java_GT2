package clase3;

public class Colecciones {

	public static void main(String[] args) {
		matrices();

	}

	public static void arrays() {
		// creacion o inicializacion
				String[] saludos=new String[4];	
				// Insercion
				saludos[0]="hola";
				saludos[1]="Adios";
				saludos[2]="Hello";
				saludos[3]="Goodbye";
				// Extraccion
				String tmp=saludos[2];
				// Borrado
				saludos[2]=null;
				//Recorrido
				for (int i = 0; i<=saludos.length;i++) {
					System.out.println(saludos[i]);
				}
				// Busqueda
				boolean sw=false;
				for (int i = 0; i<=saludos.length;i++) {
					if(saludos[i]!=null && saludos[i].equals("Adios")) {
						System.out.println("Adios ha sido encontrado en " + i);
						sw=true;
						break;
					}
				}
				
	}
	public static void matrices() {
		// tenemos [filas][columnas] --> [2][3]
		
		String[][] ciudades= {
				{"BsAs","Madrid","SaoPablo"},
				{"Argentina","Espa�a", "Brasil"}
		};
		
		for(int i=0;i<ciudades.length;i++) { // recorro por filas, length me da la dimension de las filas
			for(int j=0; j<ciudades[i].length;j++) { // recorro por columnas
				System.out.print(ciudades[i][j] + " ");
			}
			System.out.println();
		}
		
		for (String[] ciudad: ciudades) {
			System.out.print(ciudad);
		}
	}
}
