package ejerciciosTP1.ej2;

import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		Ejercicio2 ej=new Ejercicio2();
		ej.hola();
		

	}
	public void hola() {
		System.out.println("hola mundo");
	}
	public void leoTeclado() {
		System.out.println("Introduzca un Numero");
		Scanner sc = new Scanner(System.in);
		int i = sc.nextInt();
		
		if(i <=50) {
			System.out.println("Su Numero esta entre 0 y 50");
			System.out.println("suspenso");
		} else if(i >50 && i <=75) {
			System.out.println("Su Numero esta entre 51 y 75");
			System.out.println("recuperar");
		}else if(i >75 && i <=90) {
			System.out.println("Su Numero esta entre 75 y 90");
			System.out.println("aprobado");
		}else if(i >90 && i <=100) {
			System.out.println("Su Numero esta entre 91 y 100");
			System.out.println("aprobado con merito");
		} else {
			System.out.println("puntuacion invalida");
		}
	}

}
