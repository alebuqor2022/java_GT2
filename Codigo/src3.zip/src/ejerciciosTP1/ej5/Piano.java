package ejerciciosTP1.ej5;

public class Piano extends Instrumento{

	public void sonar() {
		System.out.println("Piano.sonar();");
	}
}
