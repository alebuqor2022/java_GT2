package ejerciciosTP1.ej5;

public class Guitarra extends Instrumento{

	public void sonar() {
		System.out.println("Guitarra.sonar();");
	}
}
