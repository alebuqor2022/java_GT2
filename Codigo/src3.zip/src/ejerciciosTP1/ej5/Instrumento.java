package ejerciciosTP1.ej5;

public abstract class Instrumento {

	public abstract void sonar();
}
