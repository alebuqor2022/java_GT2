package clase3_exceptions;


public class TestException {

	public static void main(String[] args) {
		Conexion c=new Conexion();
		
		try {
			c.conectar("Indra");
		} catch (ServerTimeOutException e) {
			System.out.println(e.getMessage() + " al " +e.getPuerto());
		//	e.printStackTrace();
		} catch (Exception e1) {
			System.out.println("exception general");
		} finally {
			System.out.println("fin");
		}

	}

}
