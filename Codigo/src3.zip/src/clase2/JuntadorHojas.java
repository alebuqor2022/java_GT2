package clase2;

public class JuntadorHojas {//extends Barrendero {  // NO PUEDO HACER HIJOS de Barrendero

}
