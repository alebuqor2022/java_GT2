package clase2;

public class EjemploStatico {
static String nombre;
	
	public static void main(String[] args) {
		imprimirNombre("Ale");
		nombre="Juan";
		System.out.println("chau " + nombre);

	}
	
	public static void imprimirNombre(String valor) {
		System.out.println("hola " + valor);
	}

}
