package clase2;

public interface IsetHorarios {

	void establecerHorariosAlmuerzo(String bandaHoraria);
	void establecerHorariosLaboral(String bandaHoraria);
	void establecerHorarioHorasExtras(String bandaHoraria);
}
