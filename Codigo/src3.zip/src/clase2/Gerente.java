package clase2;

public class Gerente extends Empleado implements IsetHorarios, Ipagable{
String automovil;

public String getAutomovil() {
	return automovil;
}

public void setAutomovil(String automovil) {
	this.automovil = automovil;
}

@Override
public void mostrarInfo() {
	// TODO Auto-generated method stub
	
}

@Override
public void establecerHorariosAlmuerzo(String bandaHoraria) {
	System.out.println("para almorzar va " + bandaHoraria);
	
}

@Override
public void establecerHorariosLaboral(String bandaHoraria) {
	System.out.println("para trabajar de lu a vi es " + bandaHoraria);
	
}

@Override
public void establecerHorarioHorasExtras(String bandaHoraria) {

}

@Override
public void pagar(double cantidad) {
	System.out.println("el gerente cobra 10 mil euros");
	
}

}
