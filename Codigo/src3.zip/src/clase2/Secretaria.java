package clase2;

public class Secretaria extends Empleado {
String nombreGerencia;
final String COLOR_UNIFORME ="AZUL";	

public String getNombreGerencia() {
	return nombreGerencia;
}

public void setNombreGerencia(String nombreGerencia) {
	this.nombreGerencia = nombreGerencia;
}

//public void verAntiguedad() { // no puedo hacer OVERRIDE de un metodo marcado con FINAL
//}

@Override
public void mostrarInfo1() {
	super.mostrarInfo1();
	System.out.println("soy la secretaria");
	super.legajo=2342; // lo veo por la visibilidad PROTECTED que tiene en Empleado
	
}
@Override
public void mostrarInfo() {
	String nombre= this.getNombre();
	System.out.println(nombre + " pertenece a " + this.nombreGerencia);
	
}


}
