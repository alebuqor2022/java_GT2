package clase2;

public final class Barrendero extends Empleado{ // NO PUEDO HACER HIJOS de Barrendero
String nombreCalle;
	
	@Override
	public void mostrarInfo() {
		System.out.println("barre la calle " + this.nombreCalle);
		
	}

}
