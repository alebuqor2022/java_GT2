package clase2;

public class TestArgsMain {

	public static void main(String[] args) {
		

		try {
			System.out.println(args[5]);
			
			for (int i = 0; i <= args.length; i++) {
				System.out.println(args[i]);
			}
					
		} catch (ArrayIndexOutOfBoundsException e1){
			System.out.println("esta mal el tope del largo");
		} catch (Exception e) {
			System.out.println("hay otro problema");
		}

	}

}
